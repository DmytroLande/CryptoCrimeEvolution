from pathlib import Path
import json,re,collections
P=Path(__file__).resolve().parent;rs=json.loads((P/'screened_stage.json').read_text());overrides={}
def setd(ns,decision,why):
 for n in ns:overrides[n]=(decision,why)
setd([4,10,16,24,28,39,40,45,53,54,81,108,110,114,126,129,168,206,217,247,249,261,265,304,319], 'EXCLUDE_NAVIGATION','Перевірено фрагмент і його розташування — стороння рекомендація, відеозаголовок або перелік інших матеріалів.')
setd([12,13,41,71,72,101,102,103,106,112,258,279], 'EXCLUDE_INCIDENTAL','Побіжна згадка, ринкова аналогія або матеріал на іншу тему; предметний механізм дослідження не описано.')
setd([270], 'EXCLUDE_NO_TOPIC','Текст про фінансову інклюзію та de-risking загалом; немає предметного криптовалютного механізму.')
setd([107], 'MAIN','Відновлено основний текст після передчасного навігаційного відсікання; є змістовний опис WannaCry та руху викупів.')
setd([96,139,142,175,192,194,203,277,302], 'MAIN','Перевірено предметну згадку у зв’язку з оплатою, обміном, кримінальним ринком або фінансовим моніторингом.')
setd([51,82,151], 'SUPPLEMENT','Дайджест, огляд посилань або короткий тематичний блок; не самостійне підтвердження повної схеми.')
setd([25,27,38,48,49,55,56,57,61,62,63,64,68,69,73,75,76,80,86,87,92,99,105,109,115,117,120,148,149,153,157,159,172,177,179,180,181,182,183,186,189,193,197,199,200,201,202,204,205,212,213,215,240,241,259,260,262,266,267,268,278,303,315], 'CONTEXT','Контекстна інфраструктура, оцінка ризику, рекламна заява, суміжна подія або ретроспектива; окрема доведена кримінальна схема цим записом не встановлюється.')
setd([263,264,273], 'ADJACENT_PAYMENT','Судові стадії справи Liberty Reserve — централізованої системи цифрових платежів, а не криптовалюти.')
# Repair a proven false navigation cut without treating sidebar text as evidence.
r=rs[106];r['body_paragraphs']=r['content_paragraphs'][:20];r['body']='\n'.join(p['text'] for p in r['body_paragraphs']);r['recovery_note']='Article continuation after an inline Related boundary recovered from source.'
# Externally visible publication type is determined from the export's source label, not authority scores.
official={'Federal Bureau of Investigation','US Department of State','U.S. Department of Homeland Security','U.S. Department of the Treasury','Canada News Centre'}
TAG_RULES={
'T_DARK_MARKETS':('Нелегальні онлайн-ринки',r'\bsilk road\b|\bsheep marketplace\b|\bblack market\b|\bdarknet market|\bdark web market'),
'T_WALLET_THEFT':('Викрадення гаманців або активів',r'(?:steal\w*|stolen|theft|exfiltrat\w*).{0,150}(?:wallet|bitcoin|private key)|(?:wallet|bitcoin|private key).{0,150}(?:steal\w*|stolen|theft|exfiltrat\w*)'),
'T_UNAUTH_MINING':('Ботнетний або несанкціонований майнінг',r'(?:botnet|malware|trojan|infected|compromised).{0,160}(?:mining|mine bitcoins?|miner)|(?:mining|mine bitcoins?|miner).{0,160}(?:botnet|malware|trojan|infected|compromised)'),
'T_MIXING_PRIVACY':('Змішування та інструменти приватності',r'\bmixers?\b|\bmixing\b|\btumbl\w*\b|coinjoin|bit.?laundry|bitcoin laundry|bitcoin fog|dark wallet|zerocoin|darksend'),
'T_RANSOMWARE':('Програми-вимагачі',r'cryptolocker|crypto.?wall|\bransomware\b|\breveton\b|\bransom\b'),
'T_EXCHANGE_CASHOUT':('Обмін і платіжні канали',r'cash[ -]?out|\bexchangers?\b|bitcoin exchange|exchange.{0,35}bitcoin|convert.{0,70}(?:bitcoin|dollars|fiat)|\bbitinstant\b|\blocalbitcoins\b'),
'T_REGULATION':('Ідентифікація та регуляторні механізми',r'anti.money.launder|\bAML\b|\bKYC\b|\bFinCEN\b|\bBitLicense\b|money.transmitt|money.services.business|account.verif|identity.verif'),
'T_SEIZURE':('Вилучення та конфіскація',r'\bseiz\w*\b|\bconfisc\w*\b|\bforfeit\w*\b|\bauction\w*\b'),
'T_TRACE':('Простежуваність',r'blockchain|block chain|traceab|tracing|taint analysis|de.?anonym|transaction.{0,60}track|track.{0,60}transaction'),
'T_ALT_ASSETS':('Інші активи та протоколи приватності',r'\b(?:darkcoin|litecoin|dogecoin|monero|zerocoin|ethereum|zcash|cloakcoin)\b')}
for r in rs:
 n=r['export_position'];r['decision_origin']='rule_v1';r['analyst_note']=''
 if n in overrides:r['decision'],r['reason']=overrides[n];r['decision_origin']='analyst_override_from_source_fragment'
 if r['decision']=='REVIEW':r['decision']='CONTEXT';r['reason']='Одинична змістовна згадка, збережена як контекст без підрахунку окремої кримінальної події.';r['decision_origin']='conservative_context_assignment'
 if r['decision']=='EXCLUDE_NO_CRYPTO':r['decision']='EXCLUDE_NO_TOPIC'
 body=r['body'];explicit=re.search(r'bitcoin|crypto[ -]?currenc|litecoin|darkcoin|dogecoin|monero|zerocoin',body,re.I)
 r['asset_scope']='centralized_payment_primary' if r['decision']=='ADJACENT_PAYMENT' else 'explicit_crypto' if explicit else 'virtual_currency_unspecified' if re.search(r'(?:virtual|digital)[ -]currenc',body,re.I) else 'case_context_or_other'
 r['source_type']='official_institution' if r['source_label'] in official else 'promotional_release' if r['source_label']=='PR Newswire' else 'research_institute' if r['source_label']=='The International Institute for Strategic Studies' else 'media_or_other'
 r['mixed_content']=bool(re.search(r'^home$|news.*(?:recap|digest)|coverage advisory|as it happened|^technology home$|^opinion home$|^business this week$|^letters:|^biz briefs$|^latest showbiz$|TWEET$',r['title'],re.I))
 r['tags']=[];r['tag_evidence']=[]
 if not r['decision'].startswith('EXCLUDE'):
  for code,(label,pattern) in TAG_RULES.items():
   found=[p for p in r['body_paragraphs'] if re.search(pattern,p['text'],re.I)]
   if found:
    r['tags'].append(code)
    for p in found[:2]:
     ma=re.search(pattern,p['text'],re.I);start=max(0,ma.start()-140);r['tag_evidence'].append({'tag':code,'paragraph':p['paragraph'],'line':p['line'],'start_char':start,'quote':p['text'][start:start+650]})
 r['evidence']=[]
 for p in r['body_paragraphs']:
  if re.search(r'bitcoin|crypto[ -]?currenc|virtual.currenc|liberty reserve|liberty reverse|coinjoin|dark wallet|darkcoin|ransomware',p['text'],re.I):
   r['evidence'].append({'paragraph':p['paragraph'],'line':p['line'],'quote':p['text'][:1000]})
   if len(r['evidence'])==4:break
rkeep=[r for r in rs if not r['decision'].startswith('EXCLUDE')]
(P/'adjudicated_stage.json').write_text(json.dumps(rs,ensure_ascii=False),encoding='utf-8')
(P/'codebook.json').write_text(json.dumps({'version':'1.0','tags':{k:{'label':v[0],'pattern':v[1]} for k,v in TAG_RULES.items()},'meaning':'Це лексичні індикатори тем у текстах, не доведені події чи обсяги злочинності. Час згадки не дорівнює часу виникнення механізму.','overrides':{str(k):{'decision':v[0],'reason':v[1]} for k,v in overrides.items()}},ensure_ascii=False,indent=2),encoding='utf-8')
print({y:dict(collections.Counter(r['decision'] for r in rs if r['year']==y)) for y in [2015,2016,2017]})
print('UNREVIEWED SINGLE HITS')
for r in rs:
 if r['decision_origin']=='conservative_context_assignment':print(r['export_position'],r['title'])
