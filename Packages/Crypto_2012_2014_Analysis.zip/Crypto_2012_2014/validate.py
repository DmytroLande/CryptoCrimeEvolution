from pathlib import Path
import json,re,collections,xml.etree.ElementTree as ET,hashlib,sys
from docx import Document
from lxml import html
P=Path(__file__).resolve().parent;inp=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else P.parent/'upload'/'2014.docx';rs=json.loads((P/'audit_1452.json').read_text());cases=json.loads((P/'cases.json').read_text());es=json.loads((P/'semantic_edges.json').read_text());fam=json.loads((P/'families.json').read_text());s=json.loads((P/'summary.json').read_text());ids={r['doc_id'] for r in rs};kept={r['doc_id'] for r in rs if not r['decision'].startswith('EXCLUDE')};checks={}
checks['unique1452_records']=len(ids)==len(rs)==1452
checks['year_counts']=dict(collections.Counter(r['year'] for r in rs))=={2012:24,2013:588,2014:840}
checks['retain_exclude_counts']=len(kept)==1391 and len(rs)-len(kept)==61
checks['no_unresolved_screening']=all(r['decision']!='REVIEW' for r in rs)
checks['all_have_metadata']=all(r['source_label'] and re.match(r'https?://',r['url'] or '') and r['export_date'] for r in rs)
checks['family_coverage']=sorted(x for f in fam for x in f['members'])==sorted(ids)
checks['retained_families1165']=len({r['family_id'] for r in rs if r['doc_id'] in kept})==1165
checks['family_representatives_valid']=all(r['canonical_doc_id'] in ids for r in rs)
checks['no_cross_year_families']=all(len({int(m[1:5]) for m in f['members']})==1 for f in fam)
checks['no_excluded_retained_family_mix']=all(all((m in kept)==f['retained'] for m in f['members']) for f in fam)
checks['all_case_refs_retained']=all(set(c['evidence_doc_ids'])<=kept for c in cases)
checks['all_edge_refs_retained']=all(set(e['evidence_doc_ids'])<=kept for e in es)
checks['29_dossiers_with_quotes']=len(cases)==29 and all(c['evidence'] for c in cases)
orig=Document(inp);paragraphs=[p.text.splitlines() for p in orig.paragraphs];quotes=[e for r in rs for e in r['evidence']+r['tag_evidence']]+[e for c in cases for e in c['evidence']]
checks['all_quotes_exact']=all(paragraphs[e['paragraph']-1][e['line']-1][e.get('start_char',0):].startswith(e['quote']) for e in quotes)
checks['input_hash']=hashlib.sha256(inp.read_bytes()).hexdigest()==s['input_sha256']
for y in [2012,2013,2014]:checks[f'jsonl_{y}_count']=len((P/f'clean_{y}.jsonl').read_text().splitlines())==s['years'][str(y)]['retained']
ns={'g':'http://graphml.graphdrawing.org/xmlns'};checks['pooled_graph30']=len(ET.parse(P/'Semantic_all.graphml').findall('.//g:edge',ns))==30
checks['individual_graphs_reconcile']=sum(len(ET.parse(P/f'Semantic_{y}.graphml').findall('.//g:edge',ns)) for y in [2012,2013,2014])==30
H=html.fromstring((P/'Audit_2012_2014.html').read_text());checks['html_records1452']=len(H.xpath('//details[@class="record"]'))==1452
checks['html_all_fragment_links_resolve']=all(a[1:] in set(H.xpath('//@id')) for a in H.xpath('//a/@href') if a.startswith('#'))
report=Document(P/'Report_2012_2014.docx');txt='\n'.join(p.text for p in report.paragraphs);refs=re.findall(r'D20\d\d-\d{4}',txt)
checks['report_all_document_refs_resolve']=set(refs)<=ids
checks['report_no_helper_filename']='Кри!' not in txt
checks['no_direct_crime_frequency_claim']='не інтерпретується як виміряне зростання злочинності' in txt
(P/'validation.json').write_text(json.dumps({'checks':checks,'all_passed':all(checks.values()),'quotes_checked':len(quotes),'scope':'Внутрішня узгодженість і точність цитат; не незалежна семантична експертиза.'},ensure_ascii=False,indent=2));assert all(checks.values()),checks
Path('/tmp/audit1214.js').write_text(H.xpath('//script/text()')[0])
print(json.dumps({'all_passed':all(checks.values()),'checks':len(checks),'quotes_checked':len(quotes)},ensure_ascii=False))
