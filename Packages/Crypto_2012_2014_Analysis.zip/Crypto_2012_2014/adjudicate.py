from pathlib import Path
import json,re,collections
P=Path(__file__).resolve().parent;rs=json.loads((P/'screened_stage.json').read_text());overrides={}
def setd(ns,decision,why):
 for n in ns:overrides[n]=(decision,why)
setd([13,45,47,50,52,60,61,70,96,100,129,130,131,149,150,151,159,175,241,382,650,654,656,764,885,1168,1194], 'MAIN','Перевірено змістовний фрагмент: є безпосередній зв’язок із механізмом, інфраструктурою або протидією; коротка згадка не є лише навігацією.')
setd([64,66], 'CONTEXT','Матеріал стосується того самого провадження Silk Road 2.0, але криптовалюта в основному тексті не названа; збережено як контекст справи, не як новий доказ платежу Bitcoin.')
setd([84,94,1338,1329,1334,1317,1352], 'ADJACENT_PAYMENT','Основний об’єкт — Liberty Reserve, централізована платіжна система. Порівняння або зв’язок із Bitcoin збережено, але суми цієї справи не відносяться до Bitcoin.')
setd([105,121,202,297,321,351,766,842,991,1067,1070,1183,125,500,618,658,1039,1106,1364,1368,817,1], 'CONTEXT','Перевірено контекст: огляд, аналогія, правова/ринкова інтерпретація або фонова інфраструктура; окремий кримінальний епізод цим записом не встановлений.')
setd([14,907,1014,92,253,356], 'EXCLUDE_INCIDENTAL','Побіжне порівняння або короткий перелік із Bitcoin; основний предмет не є механізмом кримінального використання чи предметною протидією.')
setd([17,308,309,310,311,312,326,463,554,556,728,1429,1438,617,1054,1219,1371,1372], 'EXCLUDE_NAVIGATION','Перевірено розташування згадки: рекомендація, пов’язана новина або відеовставка до матеріалу на іншу тему.')
setd([286,302,314], 'SUPPLEMENT','Редакційний дайджест/анонс AP; містить тематичний фрагмент, але не використовується як самостійне підтвердження або повна стаття.')
setd([279,611,724,899,1112,1325,1361,1412], 'MAIN','Перевірено тематичний зміст: приватність, інцидент, протидія або платіжна інфраструктура; оцінка правила уточнена.')
# 2012 is small enough to adjudicate all 24 entries explicitly.
for n in range(1429,1453):
 if n in [1430,1435,1436,1437,1449,1450]:overrides[n]=('MAIN','Зміст 2012 року перевірено: спеціалізовані механізми, оцінювання загроз, безпека або можливості протидії. Не всі твердження є встановленими подіями.')
 elif n in [1431,1434,1447,1448,1451,1452]:overrides[n]=('CONTEXT','Зміст 2012 року перевірено: легальна інфраструктура, авторська позиція або гіпотетичний сценарій; не доведений злочин.')
 elif n in [1429,1433,1438]:overrides[n]=('EXCLUDE_NAVIGATION','Зміст 2012 року перевірено: Bitcoin лише в рекомендаціях або переліку інших матеріалів.')
 else:overrides[n]=('EXCLUDE_NO_TOPIC','Зміст 2012 року перевірено: немає предметного опису криптовалютного механізму; електронні гроші загалом не ототожнюються з криптоактивами.')
# Externally visible publication type is determined from the export's source label, not authority scores.
official={'Federal Bureau of Investigation','US Department of State','U.S. Department of Homeland Security','U.S. Department of the Treasury','Canada News Centre'}
TAG_RULES={
'T_DARK_MARKETS':('Нелегальні онлайн-ринки',r'\bsilk road\b|\bsheep marketplace\b|\bblack market\b|\bdarknet market|\bdark web market'),
'T_WALLET_THEFT':('Викрадення гаманців або активів',r'(?:steal\w*|stolen|theft|exfiltrat\w*).{0,150}(?:wallet|bitcoin|private key)|(?:wallet|bitcoin|private key).{0,150}(?:steal\w*|stolen|theft|exfiltrat\w*)'),
'T_UNAUTH_MINING':('Ботнетний або несанкціонований майнінг',r'(?:botnet|malware|trojan|infected|compromised).{0,160}(?:mining|mine bitcoins?|miner)|(?:mining|mine bitcoins?|miner).{0,160}(?:botnet|malware|trojan|infected|compromised)'),
'T_MIXING_PRIVACY':('Змішування та інструменти приватності',r'\bmixers?\b|\bmixing\b|\btumbl\w*\b|coinjoin|bit.?laundry|bitcoin laundry|bitcoin fog|dark wallet|zerocoin|darksend'),
'T_RANSOMWARE':('Програми-вимагачі',r'cryptolocker|crypto.?wall|\bransomware\b|\breveton\b|\bransom\b'),
'T_EXCHANGE_CASHOUT':('Обмін і платіжні канали',r'cash[ -]?out|\bexchangers?\b|bitcoin exchange|exchange.{0,35}bitcoin|convert.{0,70}(?:bitcoin|dollars|fiat)|\bbitinstant\b|\blocalbitcoins\b'),
'T_REGULATION':('Ідентифікація та регуляторні механізми',r'anti.money.launder|\bAML\b|\bKYC\b|\bFinCEN\b|\bBitLicense\b|money.transmitt|money.services.business|account.verif|identity.verif'),
'T_SEIZURE':('Вилучення та конфіскація',r'\bseiz\w*\b|\bconfisc\w*\b|\bforfeit\w*\b|\bauction\w*\b'),
'T_TRACE':('Простежуваність',r'blockchain|block chain|traceab|tracing|taint analysis|de.?anonym|transaction.{0,60}track|track.{0,60}transaction'),
'T_ALT_ASSETS':('Інші активи та протоколи приватності',r'\b(?:darkcoin|litecoin|dogecoin|monero|zerocoin)\b')}
for r in rs:
 n=r['export_position'];r['decision_origin']='rule_v1';r['analyst_note']=''
 if n in overrides:r['decision'],r['reason']=overrides[n];r['decision_origin']='analyst_override_from_source_fragment'
 if r['decision']=='REVIEW':r['decision']='CONTEXT';r['reason']='Одинична змістовна згадка, збережена як контекст без підрахунку окремої кримінальної події.';r['decision_origin']='conservative_context_assignment'
 if r['decision']=='EXCLUDE_NO_CRYPTO':r['decision']='EXCLUDE_NO_TOPIC'
 body=r['body'];explicit=re.search(r'bitcoin|crypto[ -]?currenc|litecoin|darkcoin|dogecoin|monero|zerocoin',body,re.I)
 r['asset_scope']='centralized_payment_primary' if r['decision']=='ADJACENT_PAYMENT' else 'explicit_crypto' if explicit else 'virtual_currency_unspecified' if re.search(r'(?:virtual|digital)[ -]currenc',body,re.I) else 'case_context_or_other'
 r['source_type']='official_institution' if r['source_label'] in official else 'media_or_other'
 r['mixed_content']=bool(re.search(r'^home$|news.*(?:recap|digest)|coverage advisory|as it happened|^technology home$|^opinion home$|^business this week$|^letters:|^biz briefs$|^latest showbiz$|TWEET$',r['title'],re.I))
 r['tags']=[];r['tag_evidence']=[]
 if not r['decision'].startswith('EXCLUDE'):
  for code,(label,pattern) in TAG_RULES.items():
   found=[p for p in r['body_paragraphs'] if re.search(pattern,p['text'],re.I)]
   if found:
    r['tags'].append(code)
    for p in found[:2]:
     ma=re.search(pattern,p['text'],re.I);start=max(0,ma.start()-140);r['tag_evidence'].append({'tag':code,'paragraph':p['paragraph'],'line':p['line'],'start_char':start,'quote':p['text'][start:start+650]})
 r['evidence']=[]
 for p in r['body_paragraphs']:
  if re.search(r'bitcoin|crypto[ -]?currenc|virtual.currenc|liberty reserve|liberty reverse|coinjoin|dark wallet|darkcoin|ransomware',p['text'],re.I):
   r['evidence'].append({'paragraph':p['paragraph'],'line':p['line'],'quote':p['text'][:1000]})
   if len(r['evidence'])==4:break
rkeep=[r for r in rs if not r['decision'].startswith('EXCLUDE')]
(P/'adjudicated_stage.json').write_text(json.dumps(rs,ensure_ascii=False),encoding='utf-8')
(P/'codebook.json').write_text(json.dumps({'version':'1.0','tags':{k:{'label':v[0],'pattern':v[1]} for k,v in TAG_RULES.items()},'meaning':'Це лексичні індикатори тем у текстах, не доведені події чи обсяги злочинності. Час згадки не дорівнює часу виникнення механізму.','overrides':{str(k):{'decision':v[0],'reason':v[1]} for k,v in overrides.items()}},ensure_ascii=False,indent=2),encoding='utf-8')
print({y:dict(collections.Counter(r['decision'] for r in rs if r['year']==y)) for y in [2012,2013,2014]})
print('UNREVIEWED SINGLE HITS')
for r in rs:
 if r['decision_origin']=='conservative_context_assignment':print(r['export_position'],r['title'])
