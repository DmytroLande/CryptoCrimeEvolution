from pathlib import Path
import json,re,collections
P=Path(__file__).resolve().parent;rs=json.loads((P/'parsed_stage.json').read_text())
crypto=re.compile(r'\bbitcoins?\b|crypto[ -]?currenc\w*|\b(?:litecoin|dogecoin|darkcoin|zerocoin|monero)\b|(?:virtual|digital)[ -]currenc\w*',re.I)
risk=re.compile(r'launder|\b(?:criminal\w*|crime|illicit|illegal|fraud\w*|ransom\w*|malware|trojan|theft|stolen|steal\w*|confiscat\w*|seiz\w*|sanction\w*)\b|silk road|darknet|dark[ -]web|crypto.?locker|money.?mule|\b(?:mixers?|tumbler\w*|mixing)\b',re.I)
reg=re.compile(r'\b(?:regulat\w*|FinCEN|AML|KYC|anti-money|compliance|customer.identif|law.enforce|FBI|licen[cs]\w*)\b',re.I)
nav=re.compile(r'^(?:Related (?:Articles|Stories|Topics|Content|News)|See [Aa]lso|Most (?:Popular|Read|Shared)|Recommended (?:for|Stories)|You (?:may|might) also|Around the [Ww]eb|More (?:from|From)|Follow us|Comments?\s*\(|Read (?:more|More)\s*:)',re.I)
for r in rs:
 ps=r['content_paragraphs'];original='\n'.join(p['text'] for p in ps);clean=[];removed=[];length=0
 # Repeated navigation boundaries are used conservatively; inline related titles are suppressed, not blindly treated as facts.
 for i,p in enumerate(ps):
  t=p['text'].strip()
  if nav.search(t):
   if length>500 and i>4:removed+=ps[i:];break
   removed.append(p);continue
  if re.match(r'^(?:Move up|Move down|Tweet$|Share$|Print$|Email$|Follow @|READER DISCUSSION|Sponsored Links)',t):removed.append(p);continue
  # Forbes top recommendation lines have attribution suffixes; do not let their titles establish relevance.
  if length<650 and re.search(r'(?:Contributor|Forbes Staff|Forbes Contributor)\s*$',t) and len(t)<350:removed.append(p);continue
  clean.append(p);length+=len(t)
 # Analyst-reviewed recovery where page navigation precedes the article body.
 recover={1130:14,1303:19,1352:17}
 if r['export_position'] in recover:clean=ps[recover[r['export_position']]:]
 body='\n'.join(p['text'] for p in clean)
 hits=[p for p in clean if crypto.search(p['text'])];co=[p for p in hits if risk.search(p['text'])];cr=[p for p in hits if reg.search(p['text'])]
 titlecrypto=bool(crypto.search(r['title']))
 if not hits:
  if re.search(r'liberty reserve|perfect money|\be-gold\b|webmoney',body,re.I):decision='ADJACENT_PAYMENT';reason='Тематичний матеріал про суміжну систему цифрових платежів; не прирівнюється до криптовалюти.'
  elif crypto.search(original):decision='EXCLUDE_NAVIGATION';reason='Згадки криптовалют знайдено лише у відокремленому сервісному шарі.'
  else:decision='EXCLUDE_NO_CRYPTO';reason='У виділеному тексті немає явного криптовалютного компонента або предметно суміжної платіжної системи.'
 elif co and (titlecrypto or len(hits)>=2 or any(len(p['text'])>110 for p in co)):
  decision='MAIN';reason='Є явний криптовалютний контекст разом з описом кримінального механізму, ризику або протидії.'
 elif cr and (titlecrypto or len(hits)>=2):decision='MAIN';reason='Є предметний опис регулювання або спроможностей протидії щодо криптовалют.'
 elif titlecrypto or len(hits)>=2:decision='CONTEXT';reason='Криптовалюта є змістовною темою; явний кримінальний механізм не встановлено цим правилом.'
 else:decision='REVIEW';reason='Одинична згадка; потрібне окреме рішення щодо релевантності.'
 # Separate centralized digital payment systems even when Bitcoin is used as a comparison.
 if re.search(r'liberty reserve|liberty reverse',r['title'],re.I) and not re.search(r'bitcoin|crypto',r['title'],re.I):
  decision='ADJACENT_PAYMENT';reason='Основний об’єкт — централізована платіжна система Liberty Reserve; Bitcoin може згадуватися для порівняння.'
 if len(re.findall(r'liberty reserve|liberty reverse',body,re.I))>=4 and not titlecrypto and len(re.findall(r'bitcoin|crypto.?currenc',body,re.I))<=2:
  decision='ADJACENT_PAYMENT';reason='Основний зміст — суміжна централізована платіжна система; її обсяги не відносяться до Bitcoin.'
 r.update(body_paragraphs=clean,body=body,decision_rule=decision,decision=decision,reason=reason,crypto_hit_paragraphs=len(hits),risk_cooccurrence_paragraphs=len(co),reg_cooccurrence_paragraphs=len(cr),removed_paragraph_count=len(removed))
(P/'screened_stage.json').write_text(json.dumps(rs,ensure_ascii=False),encoding='utf-8')
print('COUNTS',collections.Counter(r['decision'] for r in rs))
print('BY YEAR', {str(y):dict(collections.Counter(r['decision'] for r in rs if r['year']==y)) for y in [2012,2013,2014]})
for typ in ['REVIEW','EXCLUDE_NAVIGATION','EXCLUDE_NO_CRYPTO','ADJACENT_PAYMENT']:
 print('\nCATEGORY',typ)
 for r in rs:
  if r['decision']==typ:print(r['export_position'],r['doc_id'],r['source_label'],'|',r['title'])
