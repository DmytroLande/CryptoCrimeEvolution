from pathlib import Path
import json,re,collections,hashlib,html,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent;rs=json.loads((P/'familied_stage.json').read_text());bypos={r['export_position']:r for r in rs}
# Two time axes: event_period is never silently replaced by publication year.
cases=[]
def case(cid,title,event_period,ns,status,claim,limit,pattern,phase=''):
 evidence=[]
 for n in ns:
  r=bypos[n];hits=[p for p in r['body_paragraphs'] if re.search(pattern,p['text'],re.I)]
  for p in hits[:3]:
   m=re.search(pattern,p['text'],re.I);start=max(0,m.start()-180);evidence.append({'doc_id':r['doc_id'],'paragraph':p['paragraph'],'line':p['line'],'start_char':start,'quote':p['text'][start:start+1300]})
 cases.append({'case_id':cid,'title':title,'event_period':event_period,'publication_years':sorted({bypos[n]['year'] for n in ns}),'evidence_doc_ids':[bypos[n]['doc_id'] for n in ns],'status':status,'claim':claim,'limitation':limit,'evidence':evidence,'phase':phase})
case('C12-01','Оцінка загроз у повідомленнях про документ FBI','2012; сам документ датований у статтях 24 квітня',[1449,1450],'reported_assessment','ЗМІ описують загрози, можливості аналізу та роль ідентифікації на обмінних сервісах.','У файлі наявні перекази документа, а не оригінал; приклади викрадень частково стосуються 2011 року.',r'FBI|report|assessment')
case('C12-02','Міксери як окрема сервісна функція','Опис стану на грудень 2012; дата створення сервісів не встановлена',[1430],'analytical_description','Прямо згадані bitcoin mixers та Bit Laundry як засоби приховування походження.','Огляд не доводить конкретної завершеної схеми відмивання; змішування та конвертацію потрібно розділяти.',r'mixer|Bit Laundry')
case('C12-03','Створення Bitcoin Foundation і реакція на ризики','Вересень–жовтень 2012 за публікаціями',[1435,1436],'reported_institutional_response','Повідомляється про інституційну реакцію спільноти на викрадення, ботнети та репутаційні проблеми.','Заявлені цілі організації не є виміряною ефективністю захисту.',r'Foundation|botnet|hack')
case('C12-04','Викрадення з Bitfloor','Вересень 2012 за ретроспективною згадкою у вересневій статті',[1436],'reported_theft','The Register повідомляє про викрадення 24 000 BTC із Bitfloor.','Один відібраний опис; доларовий еквівалент залежить від дати курсу.',r'Bitfloor|24,000')
case('C12-05','Bitcoin-Central і партнерська платіжна інфраструктура','Грудень 2012',[1431,1430],'reported_legitimate_infrastructure','Описано партнерство з платіжною установою та банківською інфраструктурою.','Це легальна інфраструктура; її наявність не доводить кримінального використання.',r'Bitcoin.Central|Bit.Coin Central|Aqoba|Cr.edit')
case('C12-R01','Betcoin як ретроспективно реконструйована подія','Викрадення — квітень 2012; подальший рух — із 15 березня 2013 за статтею',[1227],'retrospective_report','WIRED описує викрадення 3171 BTC, подальші «peels» і надходження частини активів на відомі біржі.','Стаття 2013 року не була доступною у 2012; надходження на біржу не доводить завершеного продажу за фіат.',r'Betcoin|peels|375|March 15')
case('C13-01','Роз’яснення FinCEN щодо посередників','Березень 2013; також ретроспективний офіційний опис 2014 року',[1421,375],'reported_regulatory_framework','У фокусі — адміністратори й обмінники та контроль входів і виходів із системи.','Авторські перекази не замінюють текст нормативного документа; правила не поширюються автоматично на будь-якого користувача.',r'guidance|administrators and exchangers|entries and exits')
case('C13-02','Обмеження банківського каналу Mt. Gox','Травень 2013',[1377,1375,1373],'reported_enforcement','Описано втручання в банківські рахунки або платіжні канали обмінника.','Не тотожне закриттю Bitcoin-мережі чи остаточному вилученню всіх активів.',r'Mt.? ?Gox|account|seiz')
case('C13-03','Закриття Liberty Reserve','Травень 2013',[1333,1352,1042],'adjacent_centralized_payment_case','Описана справа централізованої цифрової платіжної системи та її обмінників.','Приписані справі 6 млрд доларів не є обсягом Bitcoin-злочинності.',r'Liberty Reserve|\$6 billion|digital currenc')
case('C13-04','Ідентифікація клієнтів Mt. Gox','Травень–липень 2013',[1321,1315,1286],'reported_compliance_change','Описано посилення перевірки клієнтів та реєстраційні кроки обмінника.','Не доводить повного усунення анонімних каналів або фактичного виконання всіх контролів.',r'verif|identit|register')
case('C13-05','Розмежування централізованого змішування і децентралізованих пропозицій','Червень 2013',[1302],'analytical_description_and_proposals','Названі Blockchain.info mixing service, BitLaundry, Bitcoin Laundry, теоретичні децентралізовані підходи та Zerocoin.','Запропонований протокол не прирівнюється до масово впровадженої інфраструктури; твердження про ефективність не перевірялися.',r'Blockchain.info|BitLaundry|Zerocoin|decentralized mixer')
case('C13-06','Особистий обмін BTC на готівку','Липень 2013',[1268,1269],'reported_exchange_practice','Описано вуличні та особисті обміни, що доповнюють біржову інфраструктуру.','Сам обмін не позначається як злочинний; залежить від конкретних дій і правового контексту.',r'cash|street|exchange|LocalBitcoins')
case('C13-07','Дослідження простежуваності та випробування міксерів','Серпень 2013',[1227],'reported_research','Описано дослідження руху активів і проблеми довіри до сервісів змішування.','Висновки дослідників та їхні випробування переказані ЗМІ; це не наше власне блокчейн-обчислення.',r'Meiklejohn|research|mix|launder')
case('C13-08','Закриття Silk Road і затримання підозрюваного','Жовтень 2013',[1203,1194,841],'reported_takedown_and_allegations','У матеріалах вимога втручання переходить у повідомлення про закриття, затримання та вилучення.','Статус обвинуваченого зафіксовано на дату повідомлення; пізніші вироки не підставляються.',r'FBI|seiz|arrest|shut')
case('C13-09','Додаткове вилучення криптоактивів у справі Silk Road','Жовтень 2013',[1113],'official_announcement','Офіційний матеріал описує додаткову партію Bitcoin та сумарний обсяг уже вилученого.','Додаткову партію і сумарне значення не можна складати повторно; доларова оцінка є часовою.',r'144,336|173,991|seizure|seized')
case('C13-10','DarkWallet як заявлений проєкт trustless mixing','Жовтень 2013',[1091],'announced_project','Проєкт описано як розвиток приватності без передачі монет довіреному централізованому міксеру.','Анонс не є доказом готового масового продукту; заявлена непростежуваність не приймається як встановлена.',r'trustless mixing|DarkWallet|plan to include')
case('C13-11','Відновлення ринку під назвою Silk Road 2.0','Листопад 2013',[1078,1081,1082,62],'reported_reconstitution','Розглядається заміщення закритого ринку новим; документ 2014 року також описує запуск у листопаді 2013.','Існування наступника не доводить незмінного обороту чи повного відновлення мережі попередника.',r'Silk Road 2|November 2013|new|relaunch')
case('C13-12','CryptoLocker і Bitcoin-вимагання','Осінь–грудень 2013; переказ подій 2013 року є й у 2014',[877,247],'reported_ransomware','Bitcoin описаний як засіб сплати викупу; наводяться сторонні оцінки мережі адрес і доходів.','Оборот адрес не прирівнюється до доходу однієї групи; кількість заражень не дорівнює числу платників.',r'CryptoLocker|ransom|Bitcoin address')
case('C13-13','Sheep Marketplace і спірна інтерпретація зникнення коштів','Листопад–грудень 2013',[986,954],'disputed_theft_or_exit_claim','Описано зникнення ринку, заяви про викрадення, спроби простежування та можливі міксери.','Атрибуція, сума і версія exit scam залишаються спірними в цих повідомленнях.',r'Sheep|unclear|doubts|tumbler|96,000')
case('C14-01','Shrem і Faiella як один процесуальний ланцюг','Операції — грудень 2011–жовтень 2013; процесуальні стадії — 2014',[738,103,3],'charge_then_guilty_plea_then_sentence_reported','У матеріалах 2014 року наявні обвинувачення, визнання вини у роботі неліцензованого переказного бізнесу та повідомлення про вирок Shrem.','Напрям — готівка → BTC → покупки; це не приклад доведеного cash-out злочинних BTC. Стадії не рахуються як три незалежні схеми.',r'cash for Bitcoins|unlicensed|pled guilty|sentenced|Faiella',phase='Січень — обвинувачення; вересень — визнання вини; грудень — повідомлення про вирок Shrem.')
case('C14-02','Fakeplastic як приклад заміни платіжної системи','Після закриття Liberty Reserve у травні 2013; повідомлено у січні 2014',[764],'official_allegation_with_reported_payment_migration','Офіційний текст прямо описує перехід сайту з Liberty Reserve на Bitcoin.','Обвинувачення не прирівнюється до вироку; точну дату переходу не названо. Це ретроспективне свідчення адаптації 2013 року.',r'Liberty Reserve|stopped accepting|began accepting Bitcoin')
case('C14-03','Флоридські справи про особистий обмін Bitcoin','Лютий–квітень 2014',[609,604,304],'reported_charges_and_legal_dispute','Обмінні операції стають предметом конкретного правозастосування та спору про межі чинних правил.','Висновки пізніших років не використовуються; сам P2P-обмін не оголошується злочином.',r'LocalBitcoins|launder|charged|cash|unlicensed')
case('C14-04','Зупинка та банкрутство Mt. Gox','Лютий–березень 2014',[542,479,364,366],'reported_collapse_with_revised_asset_estimates','Описано операційну зупинку, заяви про зникнення активів і подальше виявлення частини Bitcoin.','Повідомлення про можливий злам не є остаточно встановленою причиною всього дефіциту; суми змінюються в часі.',r'Gox|200,000|bankrupt|lost|hack')
case('C14-05','Аукціон вилучених активів Silk Road','Червень–липень 2014',[208,200],'reported_lawful_asset_disposal','Описано аукціон, що переводить вилучені державою активи у звичайний економічний оборот.','Державна реалізація вилученого — окремий від злочинного cash-out потік; партії різних вилучень не підсумовуються автоматично.',r'auction|29,655|30,000|Marshals')
case('C14-06','Dark Wallet як ранній програмний прототип','Травень 2014; подальший опис у вересні',[279,95,96],'reported_alpha_and_privacy_claims','Описано alpha-розширення та використання CoinJoin; це відрізняється від анонсу 2013 року.','Приватність має легальні застосування; заявлену ефективність і твердження про фінансування екстремістів не вважати доведеними.',r'Alpha|CoinJoin|trustless mixing|potentially')
case('C14-07','Lecpetex і поєднання кількох компонентів','Квітень–липень 2014',[165,158],'reported_security_finding_and_arrests','Описано майнінг Litecoin на заражених машинах і розроблення підозрюваними Bitcoin-mixing сервісу.','Джерела не доводять завершеного ланцюга Litecoin → Bitcoin → міксер; ці компоненти не з’єднуються в уявну транзакцію.',r'Litecoin|mixing|Lecpetex|custody')
case('C14-08','Darkcoin у двох описаних ринках','Жовтень–листопад 2014 за статтею',[69],'reported_limited_market_adoption','Названо Nucleus та Diabolus як ринки, що почали приймати Darkcoin.','Джерело підкреслює невелику частку цих ринків; висновок про домінування альтернативних активів не робиться.',r'Darkcoin|Nucleus|Diabolus|tiny fraction')
case('C14-09','Закриття Silk Road 2.0 та операція Onymous','Листопад 2014',[62,43,50],'official_announcement_and_reported_takedowns','Документи описують втручання у ринок-наступник та ширшу міжнародну операцію.','Понад 400 .onion-адрес не дорівнює 400 незалежним ринкам; зберігається статус звинувачень.',r'400|\.onion|Silk Road 2|BENTHALL|charged')
case('C14-10','Пропозиції BitLicense та позиція EBA','Липень–листопад 2014',[148,149,124,159,175,70],'reported_regulatory_proposals','У джерелах розглядаються режими ліцензування, ідентифікації та ризик-орієнтовані вимоги.','Проєкт або позиція органу не прирівнюється до вже реалізованої спроможності чи чинного на всі дати режиму.',r'propos|Opinion|regulat|license|licen[cs]')
# Attach dossier references without conflating event year with the export date.
for r in rs:r['case_ids']=[c['case_id'] for c in cases if r['doc_id'] in c['evidence_doc_ids']]
# These are selected relations, not exhaustive automatic graph extraction.
relations=[]
def edge(y,a,rel,b,ns,status,period=None):
 relations.append({'edge_id':f'R{len(relations)+1:03}','observation_year':y,'event_period':period or str(y),'source':a,'relation':rel,'target':b,'evidence_doc_ids':[bypos[n]['doc_id'] for n in ns],'status':status})
edge(2012,'Bit Laundry','described_as','Bitcoin mixing service',[1430],'media_description')
edge(2012,'FBI assessment coverage','discusses','Bitcoin illicit-use risks',[1449,1450],'media_report_of_assessment')
edge(2012,'Bitfloor','reported_target_of','Bitcoin theft',[1436],'reported_single_source')
edge(2012,'Bitcoin-Central','partners_with','Aqoba',[1431,1430],'legitimate_infrastructure')
edge(2013,'FinCEN guidance','described_as_covering','Administrators and exchangers',[1421,375],'media_and_retrospective_official_description')
edge(2013,'Mt. Gox','requires','Customer identification',[1321,1315],'reported_compliance')
edge(2013,'Mt. Gox banking channel','subject_to','Enforcement action',[1377,1375],'reported_enforcement')
edge(2013,'Liberty Reserve','subject_to','Shutdown',[1333,1352],'adjacent_payment_system')
edge(2013,'Blockchain.info mixing service','described_as','Centralized mixing',[1302],'media_description')
edge(2013,'Zerocoin','proposed_for','Decentralized privacy',[1302],'proposal_not_deployment')
edge(2013,'Betcoin stolen funds','reportedly_moved_via','Peeling sequence',[1227],'retrospective_media_report','Theft 2012; movement 2013')
edge(2013,'Betcoin funds','reportedly_reach','Known Bitcoin exchanges',[1227],'reported_exchange_arrival_not_confirmed_fiat_sale','Theft 2012; movement 2013')
edge(2013,'In-person exchange','converts','Cash and Bitcoin',[1268,1269],'legitimate_or_context_dependent')
edge(2013,'Silk Road','subject_to','Law-enforcement takedown',[1203,841],'reported_takedown')
edge(2013,'Silk Road 2.0','replaces','Silk Road marketplace',[1078,1081,62],'reported_reconstitution')
edge(2013,'DarkWallet proposal','includes','Trustless mixing',[1091],'announced_project')
edge(2013,'CryptoLocker','demands','Bitcoin ransom',[877],'reported_ransomware')
edge(2013,'Sheep Marketplace','associated_with','Disputed asset disappearance',[986,954],'unresolved_theft_or_exit_claim')
edge(2014,'Faiella and Shrem service','converts','Cash into Bitcoin',[103,3],'official_guilty_plea_and_sentence_announcements','Operations 2011–2013; case stages 2014')
edge(2014,'Bitcoin supplied by exchange service','used_for','Silk Road purchases',[103,3],'official_announcements','Operations 2011–2013; case stages 2014')
edge(2014,'Fakeplastic','changes_payment_from','Liberty Reserve',[764],'official_allegation','After May 2013; reported January 2014')
edge(2014,'Fakeplastic','changes_payment_to','Bitcoin',[764],'official_allegation','After May 2013; reported January 2014')
edge(2014,'Dark Wallet alpha','uses','CoinJoin',[279],'reported_early_software')
edge(2014,'Lecpetex','mines','Litecoin',[165,158],'reported_security_finding')
edge(2014,'Lecpetex suspects','reportedly_develop','Bitcoin mixing service',[165,158],'reported_claim_no_completed_cross_asset_path')
edge(2014,'Nucleus marketplace','accepts','Darkcoin',[69],'reported_limited_adoption')
edge(2014,'Diabolus marketplace','accepts','Darkcoin',[69],'reported_limited_adoption')
edge(2014,'Seized Silk Road assets','subject_to','Government auction',[208,200],'lawful_disposal_not_criminal_cashout')
edge(2014,'Silk Road 2.0','subject_to','Takedown and charges',[62,43],'official_allegations_and_takedown')
edge(2014,'BitLicense','described_as','Proposed regulatory regime',[148,149,70],'proposal')
# Export all records once, retaining paragraphs for exact evidence audit.
(P/'audit_1452.json').write_text(json.dumps(rs,ensure_ascii=False),encoding='utf-8')
(P/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2),encoding='utf-8');(P/'semantic_edges.json').write_text(json.dumps(relations,ensure_ascii=False,indent=2),encoding='utf-8')
kept=[r for r in rs if not r['decision'].startswith('EXCLUDE')]
for y in [2012,2013,2014]:(P/f'clean_{y}.jsonl').write_text('\n'.join(json.dumps({k:v for k,v in r.items() if k not in ['content_paragraphs','body_paragraphs']},ensure_ascii=False) for r in kept if r['year']==y)+'\n',encoding='utf-8')
summary={'version':'1.0','input_name':'2014.docx','input_sha256':hashlib.sha256((P.parent/'upload'/'2014.docx').read_bytes()).hexdigest(),'query':'(bitcoin | cryptocurrency | (virtual~currency)) & (crime | criminal | illicit | fraud | darknet | drugs | laundering | (money~laundering)) & (cashout | exchanger | laundering | mixer | mixing)','query_policy':'Адаптивний відбір; запити та поняття можуть змінюватися в часі. Результати частот не є оцінкою популяційної поширеності.','all_records':len(rs),'retained':len(kept),'excluded':len(rs)-len(kept),'years':{},'dossiers':len(cases),'selected_edges':len(relations),'tag_semantics':'Лексичні індикатори тем, а не незалежні події.','validation_scope':'Програмний скринінг усіх записів, адресні аналітичні уточнення та перевірені цитатні опори для каталогу; без незалежного сліпого кодування або зовнішнього веб-пошуку.'}
for y in [2012,2013,2014]:
 ys=[r for r in rs if r['year']==y];ks=[r for r in ys if not r['decision'].startswith('EXCLUDE')]
 summary['years'][str(y)]={'all':len(ys),'decision_counts':dict(collections.Counter(r['decision'] for r in ys)),'retained':len(ks),'excluded':len(ys)-len(ks),'text_families':len({r['family_id'] for r in ks}),'all_date_range':[min(r['export_date'] for r in ys),max(r['export_date'] for r in ys)],'retained_date_range':[min(r['export_date'] for r in ks),max(r['export_date'] for r in ks)],'source_labels':len({r['source_label'] for r in ks}),'source_types':dict(collections.Counter(r['source_type'] for r in ks)),'decisions_origin':dict(collections.Counter(r['decision_origin'] for r in ys)),'month_counts_all':dict(sorted(collections.Counter(r['export_date'][:7] for r in ys).items())),'month_counts_retained':dict(sorted(collections.Counter(r['export_date'][:7] for r in ks).items()))}
(P/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
# Preserve a compact baseline, with no modification to the earlier research package.
b=P.parent/'Crypto_2011'/'summary.json'
if b.exists():(P/'baseline_2011_summary.json').write_bytes(b.read_bytes())
# GraphML for each observed publication year and the pooled temporal network.
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
for y in [2012,2013,2014,'all']:
 edges=[e for e in relations if y=='all' or e['observation_year']==y];root=ET.Element('{'+ns+'}graphml')
 for key,domain in [('label','node'),('relation','edge'),('year','edge'),('period','edge'),('evidence','edge'),('status','edge')]:ET.SubElement(root,'{'+ns+'}key',{'id':key,'for':domain,'attr.name':key,'attr.type':'string'})
 g=ET.SubElement(root,'{'+ns+'}graph',{'id':'G'+str(y),'edgedefault':'directed'});nodes=sorted({e[k] for e in edges for k in ['source','target']});nid={s:'n'+str(i) for i,s in enumerate(nodes)}
 for s in nodes:node=ET.SubElement(g,'{'+ns+'}node',{'id':nid[s]});ET.SubElement(node,'{'+ns+'}data',{'key':'label'}).text=s
 for e in edges:
  node=ET.SubElement(g,'{'+ns+'}edge',{'id':e['edge_id'],'source':nid[e['source']],'target':nid[e['target']]})
  for k,val in [('relation',e['relation']),('year',str(e['observation_year'])),('period',e['event_period']),('evidence',','.join(e['evidence_doc_ids'])),('status',e['status'])]:ET.SubElement(node,'{'+ns+'}data',{'key':k}).text=val
 ET.ElementTree(root).write(P/f'Semantic_{y}.graphml',encoding='utf-8',xml_declaration=True)
print(json.dumps(summary,ensure_ascii=False,indent=2))
