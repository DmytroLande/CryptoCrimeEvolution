from pathlib import Path
import json,collections,hashlib,html,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
rs=json.loads((P/'familied_stage.json').read_text());by={r['export_position']:r for r in rs}
def save(name,data): (P/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
cases=[]
def case(cid,title,period,status,finding,caution,evidence,functions,family):
 es=[]
 for n,needle in evidence:
  r=by[n];ps=[p for p in r['content_paragraphs'] if needle.lower() in p['text'].lower()]
  assert ps,(cid,n,needle)
  p=ps[0];i=max(0,p['text'].lower().index(needle.lower())-120)
  es.append(dict(doc_id=r['doc_id'],publication_date=r['export_date'],source=r['source_label'],url=r['url'],paragraph=p['paragraph'],line=p['line'],start_char=i,quote=p['text'][i:i+1500]))
 cases.append(dict(case_id=cid,title=title,case_family=family,event_period=period,claim_status=status,finding=finding,caution=caution,functions=functions,evidence=es))
from case_definitions import CARDS
for args in CARDS:case(*args)
save('cases.json',cases)
families=json.loads((P/'families.json').read_text())
summary={'input':'2022-1.docx','sha256':hashlib.sha256((P.parent/'upload/2022-1.docx').read_bytes()).hexdigest(),'all':len(rs),'retained':sum(not r['decision'].startswith('EXCLUDE') for r in rs),'case_cards':len(cases),'query':'(cryptocurrency | bitcoin | ethereum | monero | stablecoin | USDT] | DeFi | (virtual~asset)) & (illicit | ransomware | laundering) & (cashout | OTC] | P2P | mixer | DEX] | bridge | (cross~chain) | (money~mule))','years':{}}
for y in [2021,2022]:
 a=[r for r in rs if r['year']==y];k=[r for r in a if not r['decision'].startswith('EXCLUDE')]
 summary['years'][str(y)]={'all':len(a),'retained':len(k),'excluded':len(a)-len(k),'retained_families':sum(f['retained'] and f['year']==y for f in families),'decision_counts':dict(collections.Counter(r['decision'] for r in a)),'months_all':dict(sorted(collections.Counter(r['export_date'][:7] for r in a).items())),'source_labels':len(set(r['source_label'] for r in k))}
 (P/f'clean_{y}.jsonl').write_text('\n'.join(json.dumps({a:b for a,b in r.items() if a not in ['content_paragraphs','body_paragraphs']},ensure_ascii=False) for r in k)+'\n',encoding='utf-8')
save('summary.json',summary);save('audit_1478.json',rs)
# One edge per functional interpretation; these are not blockchain transactions.
edges=[]
for c in cases:
 for f in c['functions']:
  edges.append(dict(edge_id=f"E{len(edges)+1:03}",source=c['case_id'],target=f,relation='documented_function_or_context',event_period=c['event_period'],publication_years=sorted(set(e['publication_date'][:4] for e in c['evidence'])),doc_ids=sorted(set(e['doc_id'] for e in c['evidence'])),claim_status=c['claim_status']))
save('semantic_edges.json',edges)
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
root=ET.Element('{'+ns+'}graphml');g=ET.SubElement(root,'{'+ns+'}graph',edgedefault='directed')
for node in sorted(set(e[k] for e in edges for k in ['source','target'])):ET.SubElement(g,'{'+ns+'}node',id=node)
for e in edges:ET.SubElement(g,'{'+ns+'}edge',id=e['edge_id'],source=e['source'],target=e['target'])
ET.ElementTree(root).write(P/'Semantic_all.graphml',encoding='utf-8',xml_declaration=True)
print(summary);print('EDGES',len(edges))
