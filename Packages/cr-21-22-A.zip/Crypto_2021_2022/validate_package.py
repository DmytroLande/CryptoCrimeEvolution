from pathlib import Path
import json,hashlib,collections,xml.etree.ElementTree as ET,sys,re
from docx import Document
P=Path(__file__).resolve().parent
source=Path(sys.argv[1]) if len(sys.argv)>1 else P.parent/'upload/2022-1.docx'
rs=json.loads((P/'audit_1478.json').read_text());cs=json.loads((P/'cases.json').read_text());s=json.loads((P/'summary.json').read_text());edges=json.loads((P/'semantic_edges.json').read_text());fs=json.loads((P/'families.json').read_text())
checks=[]
def check(name,result):
 checks.append({'check':name,'passed':bool(result)});assert result,name
check('1478 source records',len(rs)==1478)
check('unique document IDs',len(set(r['doc_id'] for r in rs))==1478)
check('source SHA256',hashlib.sha256(source.read_bytes()).hexdigest()==s['sha256'])
check('year counts',dict(collections.Counter(r['year'] for r in rs))=={2021:683,2022:795})
check('decisions resolved',all(r['decision']!='REVIEW' for r in rs))
check('retained counts',sum(not r['decision'].startswith('EXCLUDE') for r in rs)==703)
check('families partition',sorted(x for f in fs for x in f['members'])==sorted(r['doc_id'] for r in rs))
check('retained text families',sum(f['retained'] for f in fs)==697)
check('34 cards',len(cs)==34 and len(set(c['case_id'] for c in cs))==34)
check('100 interpretation edges',len(edges)==100)
ids={r['doc_id']:r for r in rs};cids={c['case_id'] for c in cs}
check('edge references',all(e['source'] in cids and all(i in ids for i in e['doc_ids']) for e in edges))
D=Document(source);orig={(i,j):line for i,p in enumerate(D.paragraphs,1) for j,line in enumerate(p.text.splitlines(),1)}
count=0
for r in rs:
 for p in r['body_paragraphs']:
  checktext=orig[(p['paragraph'],p['line'])];assert p['text']==checktext,(r['doc_id'],p);count+=1
 for e in r['tag_evidence']:
  text=orig[(e['paragraph'],e['line'])];assert text[e['start_char']:e['start_char']+len(e['quote'])]==e['quote'];count+=1
for c in cs:
 assert c['evidence']
 for e in c['evidence']:
  assert e['doc_id'] in ids and not ids[e['doc_id']]['decision'].startswith('EXCLUDE')
  text=orig[(e['paragraph'],e['line'])];assert text[e['start_char']:e['start_char']+len(e['quote'])]==e['quote'];count+=1
check('all evidence matches original DOCX',True)
for y in [2021,2022]:
 data=[json.loads(l) for l in (P/f'clean_{y}.jsonl').read_text().splitlines()]
 check(f'{y} JSONL count and year',len(data)==s['years'][str(y)]['retained'] and all(r['year']==y for r in data))
ht=(P/'Audit_2021_2022.html').read_text()
check('HTML all document anchors',all('id="'+i+'"' in ht for i in ids))
check('HTML all case anchors',all('id="'+i+'"' in ht for i in cids))
g=ET.parse(P/'Semantic_all.graphml');check('GraphML edge count',len(g.findall('.//{http://graphml.graphdrawing.org/xmlns}edge'))==100)
doc=Document(P/'Report_2021_2022.docx');text='\n'.join(p.text for p in doc.paragraphs)
check('article fragment present','Фрагмент результатів для статті' in text)
check('source closing metadata count',sum(bool(re.match(r'^(.+?)\s+(20\d\d\.\d\d\.\d\d)\s+(\d\d:\d\d)\s*$',v.strip())) for v in orig.values())==1478)
check('recovered omitted separator',set(r['doc_id'] for r in rs if r.get('separator_recovery'))=={'D2022-0500','D2022-0501'})
routes=json.loads((P/'mechanism_routes.json').read_text())['routes']
check('six route fragments',len(routes)==6)
check('route references',all(r['case_id'] in cids and all(e['doc_id'] in ids for e in r['evidence']) for r in routes))
check('route edge endpoints',all(all(e['source'] in {n['node_id'] for n in r['nodes']} and e['target'] in {n['node_id'] for n in r['nodes']} for e in r['edges']) for r in routes))
check('route future return distinguished',routes[-1]['edges'][-1]['status']=='announced_future')
result={'checks':checks,'passed':all(x['passed'] for x in checks),'exact_source_fragments_checked':count,'semantic_validation':'One analytical coding pass with targeted source review; no blind independent validation or external investigation.'}
(P/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'checks':len(checks),'passed':result['passed'],'source_fragments':count}))
