from pathlib import Path
import json,collections,csv,platform,importlib.metadata,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
s=json.loads((P/'summary.json').read_text());rs=json.loads((P/'audit_800.json').read_text());cs=json.loads((P/'cases.json').read_text());by={c['case_id']:c for c in cs};prev=json.loads((P/'prior_metadata.json').read_text())
def save(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
q=prev['query_registry'];q['versions'].append({'period':'2025–2026 through 2026-09-29','query_verbatim_spacing_normalized':s['query'],'source':'query table in 2026.docx','syntax_not_validated':['OTC]','offshore VASP spacing/operator interpretation'],'changes':['Third block adds (unhosted~wallet) and (offshore VASP)','2026 is partial; counts not annualized','Vocabulary is adaptive; cannot infer incidence or disappearance from query terms']});save('query_registry.json',q)
e=prev['entity_mapping'];e['rules'] += [
 {'entity':'eXch / Chainflip / Bybit','meaning':'Separate services and target; named in analyst account; eXch disputes wrongdoing; no inferred fiat completion'},
 {'entity':'gone dark / cashed out','meaning':'Loss of traceability and verified fiat payout differ; preserve reported cashout as attributed claim'},
 {'entity':'Cryptomixer / ChipMixer / mixer','meaning':'Specific service names versus generic mechanism; no automatic identity merge'},
 {'entity':'Kyrrex St Vincent / Malta affiliate / brand','meaning':'Distinct legal entities; common ownership does not collapse legal identity; claimed nesting is disputed'},
 {'entity':'Huobi / HTX','meaning':'Renamed brand; preserve dates and corporate entity scope; host of another service not always final customer'},
 {'entity':'A7 / A7A5 / USDT','meaning':'Payment firm, rouble-linked stablecoin and dollar-linked stablecoin; distinguish settlement turnover, liquidity and market capitalization'},
 {'entity':'KYC record / account / person','meaning':'Purchased or stolen identity and recruited mule differ; 6000 KYC records do not prove 6000 identified offenders'},
 {'entity':'unhosted wallet / offshore VASP','meaning':'Custody and jurisdiction characteristics; neither automatically proves crime'},
 {'entity':'partial mistrial / conviction / retrial request','meaning':'Count-level legal statuses, not all-purpose guilt or acquittal; requested future event is not observed'},
 {'entity':'seizure / final forfeiture / victim return','meaning':'Control of assets, transfer of legal ownership and compensation differ'},
 {'entity':'CMLN','meaning':'Chinese-language network category; language not nationality or ethnicity; wallets not persons'},
 {'entity':'TVL outflow / stolen assets','meaning':'Market or platform liquidity movement is not sum stolen in attack'},
 {'entity':'admin multisig / program flaw','meaning':'Control-plane compromise distinguished from exploit in contract code and seed theft'}];save('entity_mapping.json',e)
i=prev['cumulative_inventory'];i['all_records']+=800;i['batches'].append({'period':'2025–2026 to 2026-09-29','all':800});i['cutoff']='2026-09-29';save('cumulative_inventory.json',i)
links=[('C24-21','C25-03','Garantex','Sanctions and investigation → infrastructure seizure and personal charges'),('C24-07','C25-04','Tornado_OFAC_civil','Appellate ruling → delisting'),('C23-12','C25-05','Tornado_US_criminal','Charges → count-specific partial verdict'),('C25-05','C26-19','Tornado_US_criminal','Partial verdict → requested retrial, not completed trial'),('C24-08','C25-06','Samourai','Charges → reported plea and sentences; source contradictions retained'),('C23-04','C25-07','Blender_Sinbad','Analytical relationship hypothesis → alleged common operators'),('C23-18','C25-07','Sinbad','Sanction/designation → operator charges'),('C24-04','C26-07','Helix','Sentence → final forfeiture order'),('C24-13','C25-21','Lam_Serrano','Initial theft case → specialist crypto-to-wire role'),('C25-21','C26-05','Lam_Serrano','Intermediary plea → separate intermediary sentence'),('C24-13','C26-06','Lam_Serrano','Initial case → plea in wider RICO enterprise'),('C25-22','C26-04','Uranium_2021','Recovery report → charges; dates and amounts not perfectly concordant'),('C25-01','C25-02','Bybit_2025','Initial attribution → later cashout claim and visibility loss'),('C25-11','C26-16','HTX','Nested service investigation → address-rotation investigation'),('C21-10','C25-17','NCET','2021 announcement and 2022 launch → 2025 reorganization'),('C25-19','C26-13','Scam_compounds','Prince Group context → separate Xinbi/#8 Park sanctions; not one merged event')]
save('continuity_links.json',{'meaning':'Curated case or context links; not payment edges. Prior IDs refer to earlier packages.','links':[dict(from_case=a,to_case=b,family=f,relationship=r) for a,b,f,r in links]})
save('case_family_index.json',{'families':[{'family':f,'cards':[c['case_id'] for c in cs if c['case_family']==f]} for f in sorted(set(c['case_family'] for c in cs))]})
save('topic_screening_counts.json',{'meaning':'Overlapping lexical document indicators, not event or mechanism counts','years':{str(y):dict(collections.Counter(t for r in rs if r['year']==y and not r['decision'].startswith('EXCLUDE') for t in r['tags'])) for y in [2025,2026]}})
save('source_anomalies.json',{'declared_and_parsed_records':800,'date_min':s['date_min'],'date_max':s['date_max'],'items':[
 {'docs':['D2025-0074','D2025-0076','D2025-0202'],'issue':'Samourai plea month and offense wording differ across reports','treatment':'Preserve contradictory variants; 5/4 year sentences consistent; no independent court-record check'},
 {'docs':['D2025-0413','D2026-0175'],'issue':'First Uranium attack dated April 6 versus April 8; loss estimates differ','treatment':'Same case family with source-specific values; no silent replacement'},
 {'docs':['D2025-0516'],'issue':'Sentence lists Blender/Sinbad dates in inconsistent order; large Ronin-linked amount also differs from earlier source scope','treatment':'Do not use for normalized sanction dates or one cumulative amount'},
 {'docs':['D2025-0365'],'issue':'Ronin theft described partly as April 2022 rather than March; April related to attribution/sanction chronology','treatment':'Separate event and later official actions'},
 {'docs':['D2026-0027'],'issue':'Text says 4100 BTC worth over $230, missing million; wider totals 245/263m have distinct scope','treatment':'Flag typo, do not use literally or sum values'},
 {'docs':['D2025-0388'],'issue':'Cashed out in headline/opening versus gone dark in explanation','treatment':'Attributed claim; no independent fiat endpoint proof'},
 {'docs':['D2025-0474'],'issue':'2023 ransomware base now 1.25bn, earlier batch 1.1bn','treatment':'Store estimation vintage'},
 {'docs':['D2026-0264'],'issue':'Headline 17bn versus at least 14bn observed and projected >17bn','treatment':'Separate observed estimate, revision and coverage forecast'},
 {'docs':['D2026-0232','D2026-0238','D2026-0264'],'issue':'TRM and Chainalysis use different scope and definitions','treatment':'No merged annual numerical series or independent replication claim'},
 {'docs':['D2025-0393'],'issue':'Freeze amounts 26m and 27m appear in same operation','treatment':'Do not sum without overlap check'},
 {'docs':['D2025-0272'],'issue':'Suit used for Sui in cross-chain passage','treatment':'Original retained; normalized network name separate'},
 {'docs':['D2026-0202'],'issue':'Requested October retrial beyond corpus cutoff; defense calls timing premature','treatment':'announced_future only, not confirmed schedule or outcome'},
 {'docs':['D2025-0008'],'issue':'Generic pipeline narrative with casino insertion, no named case','treatment':'Context only, no case or route built from it'},
 {'docs':['D2025-0122','D2025-0328'],'issue':'Paywall-limited extracts','treatment':'Claims restricted to substantive available fragments'},
 {'docs':['D2026-0011'],'issue':'Abstract-level method and author-reported scores only','treatment':'No reproduced experiment or full-paper review claimed'}]})
periods=[
 ('2011',212,'Оплата, ранні ринки, приватність і припущення про кримінальні канали','Crypto_2011'),
 ('2012–2014',1452,'Спеціалізація обміну, darknet, змішування, KYC і вилучення','Crypto_2012_2014'),
 ('2015–2017',326,'Ransomware як послуга, багатoактивні маршрути й посередники','Crypto_2015_2017'),
 ('2018–2020',1338,'OTC, банки, готівка, стейблкоїни та комбінації приховування','Crypto_2018_2020'),
 ('2021–2022',1478,'Мости й DeFi як цілі та інструменти, смартконтракти, вкладені сервіси','Crypto_2021_2022'),
 ('2023–2024',863,'Адаптація сервісів, фіатні посередники та розгалуження судових процедур','Crypto_2023_2024'),
 ('2025–2026',800,'Спеціалісти конвертації, ринки ідентичностей, юрисдикції та стейблкоїнні розрахунки','Crypto_2025_2026')]
save('evolution_matrix.json',{'meaning':'Curated functional periodization, not incidence trend. Profiles indicate documented visibility, not mechanism birth or exclusive dominance. Final year partial.','cutoff':'2026-09-29','all_records':6469,'periods':[dict(period=a,all=b,profile=c,source_package=d) for a,b,c,d in periods]})
with (P/'evolution_matrix.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['period','raw_records','documented_functional_profile','source_package']);w.writerows(periods)
save('model_specification.json',{
 'status':'Proposed coding specification, no fitted transition probabilities or numerical forecast',
 'unit':'Episode or partially documented route, not article, address, whole case or whole platform',
 'dimensions':{'origin':['theft','ransom','fraud','IT_revenue','other','unknown'],'control':['private_key','signing_process','admin_authority','program_exploit','unknown'],'transfer':['wallet_transfer','asset_swap','cross_chain','unknown'],'concealment':['mixer','nested_service','address_rotation','identity_rental','other','unknown'],'realization':['fiat_bank','fiat_cash','material_asset','direct_crypto_payment','unknown'],'response':['block','seize','charge','plea','verdict_by_count','sentence','final_forfeiture','policy_change','unknown']},
 'required_fields':['episode_id','case_family','event_time','publication_time','query_version','source_id','claim_status','evidence_coordinates','scope_denominator','unknown_stages'],
 'observations':['New event evidence','Retrospective evidence about earlier event','New attribution or legal status','Coverage or estimate revision','Missing evidence, not observed mechanism termination'],
 'guards':['Do not infer fiat exit from exchange deposit or visibility loss','Do not infer next stage from presence of previous stage','Do not join unrelated cases into transaction path','Deduplicate repeat publications separately from case continuity','Treat partial-year coverage explicitly','Source-reported analytical scores are not our experimental results'],
 'next_estimation_requirements':['Harmonize episodes across all batches','Re-review boundary relevance and service identities','Define time windows and comparable risk set','Separate missingness from transition absence','Retain estimate vintages and count-level legal status']})
routes=[]
def route(rid,cid,kind,labels,statuses):
 c=by[cid];nodes=[dict(node_id=rid+'_'+str(i),label=t) for i,t in enumerate(labels)]
 edges=[dict(source=nodes[i]['node_id'],target=nodes[i+1]['node_id'],relation='source_backed_semantic_stage',status=statuses[i]) for i in range(len(labels)-1)]
 routes.append(dict(route_id=rid,case_id=cid,kind=kind,nodes=nodes,edges=edges,evidence=c['evidence'],caution=c['caution']))
route('R01','C25-21','reported_plea_crypto_to_wire',['Криптовалюта групи','Mehta і співучасники','Банківські перекази від інших підставних компаній','Рахунки компаній Mehta'],['reported_plea','reported_plea','reported_plea'])
route('R02','C25-09','alleged_service_function',['Криптодоходи від атак','E-Note і мережа посередників','Фіатна конвертація за обвинуваченням'],['alleged','alleged_no_transaction_reconstruction'])
route('R03','C25-13','police_account_bank_return',['Гроші потерпілого на банківських рахунках','Рахунки підставних компаній','USDT','Binance P2P','Особисті банківські рахунки'],['police_allegation','police_allegation','police_allegation','police_allegation_not_cash_withdrawal'])
route('R04','C25-01','disputed_crypto_swap',['Викрадені ETH і stETH Bybit','Названі аналітиками eXch і Chainflip','BTC як напрям конвертації'],['analyst_account_disputed','analyst_account_no_fiat_proof'])
route('R05','C25-14','partial_asset_swap',['Викрадені активи Cetus','Обмін USDT на USDC','Спроби міжмережевого руху Sui→Ethereum'],['analyst_account','analyst_account_not_all_assets'])
route('R06','C25-15','reported_admin_takeover',['Контроль multisig Unleash','Несанкціоноване оновлення контракту','Виведення токенів','Стороння міжмережева інфраструктура','ETH у Tornado Cash'],['company_initial_account','company_initial_account','company_and_analyst_account','analyst_account_no_fiat_proof'])
route('R07','C26-04','alleged_material_realization',['Викрадені активи Uranium 2021','DEX і Tornado Cash','Колекційні картки та антична монета'],['alleged_no_exact_transaction_path','alleged_material_realization'])
route('R08','C26-10','reported_FIU_case',['Надходження USDT','Негайна ліквідація на VDA-сервісі','INR на банківських рахунках'],['FATF_case_relay','FATF_case_relay_no_universal_guilt_inference'])
route('R09','C26-01','alleged_service_roles',['Криптоактиви клієнтів AudiA6','Біржові акаунти з викраденими або придбаними ідентичностями','Складні маршрути приховування','Повернення клієнтам за вирахуванням комісії'],['alleged_function_not_transaction_order','alleged_function','reported_service_description_asset_unspecified'])
route('R10','C26-19','procedural_not_funds_route',['Немає згоди присяжних за двома пунктами у 2025','Запит прокурорів про повторний розгляд у 2026','Запропонований майбутній розгляд у жовтні'],['reported_procedural_request','announced_future'])
save('mechanism_routes.json',{'meaning':'Nine partial functional sequences and one procedural sequence. Not transaction reconstruction. Each route has local nodes, attributed status and source evidence. No unknown stages filled.','routes':routes})
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
root=ET.Element('{'+ns+'}graphml');ET.SubElement(root,'{'+ns+'}key',id='label',**{'for':'node','attr.name':'label','attr.type':'string'});ET.SubElement(root,'{'+ns+'}key',id='status',**{'for':'edge','attr.name':'status','attr.type':'string'});g=ET.SubElement(root,'{'+ns+'}graph',edgedefault='directed')
for r in routes:
 for n in r['nodes']:
  el=ET.SubElement(g,'{'+ns+'}node',id=n['node_id']);ET.SubElement(el,'{'+ns+'}data',key='label').text=n['label']
 for j,e in enumerate(r['edges']):
  el=ET.SubElement(g,'{'+ns+'}edge',id=r['route_id']+'e'+str(j),source=e['source'],target=e['target']);ET.SubElement(el,'{'+ns+'}data',key='status').text=e['status']
ET.ElementTree(root).write(P/'Mechanism_routes.graphml',encoding='utf-8',xml_declaration=True)
save('runtime_versions.json',{'python':platform.python_version(),'packages':{x:importlib.metadata.version(x) for x in ['python-docx','numpy','scikit-learn']}})
print('Supplementary registers, evolution matrix, model specification and ten sequences created')
