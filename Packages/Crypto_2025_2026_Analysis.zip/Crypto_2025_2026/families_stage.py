from pathlib import Path
import json,re,collections,hashlib,datetime
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors
P=Path(__file__).resolve().parent;rs=json.loads((P/'adjudicated_stage.json').read_text())
def tokens(r):
 ps=r['body_paragraphs'][1:]
 txt=' '.join(p['text'] for p in ps if not re.match(r'^(?:By |Photographer:|Photo:|Copyright|©|Follow |Related:|Share|Tweet|Print|Email)',p['text'],re.I))
 return re.findall(r'[a-z0-9]+',txt.lower())
ts=[tokens(r) for r in rs];norm=[' '.join(t) for t in ts]
sha=[hashlib.sha256(t.encode()).hexdigest() for t in norm]
sets=[set(tuple(t[i:i+6]) for i in range(len(t)-5)) for t in ts]
N=len(rs);parent=list(range(N));edges=[]
def find(i):
 while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
 return i
# Exact normalized text groups are allowed only within one publication year.
seen={}
for i,r in enumerate(rs):
 k=(r['year'],sha[i],r['decision'].startswith('EXCLUDE'))
 if len(ts[i])>=45 and k in seen:parent[i]=find(seen[k]);edges.append({'a':rs[seen[k]]['doc_id'],'b':r['doc_id'],'method':'normalized_exact','jaccard':1.0})
 else:seen[k]=i
v=TfidfVectorizer(min_df=1,max_df=.95,max_features=50000,ngram_range=(1,2),dtype=np.float32)
X=v.fit_transform(norm);nn=NearestNeighbors(n_neighbors=min(40,N),metric='cosine',algorithm='brute',n_jobs=1).fit(X);dist,inds=nn.kneighbors(X)
candidates=[]
for i in range(N):
 for dis,j in zip(dist[i],inds[i]):
  j=int(j)
  if j<=i or dis>.22:continue
  a,b=rs[i],rs[j]
  if a['year']!=b['year'] or a['decision'].startswith('EXCLUDE')!=b['decision'].startswith('EXCLUDE'):continue
  days=abs((datetime.date.fromisoformat(a['export_date'])-datetime.date.fromisoformat(b['export_date'])).days)
  if days>7:continue
  if not sets[i] or not sets[j]:continue
  ratio=min(len(ts[i]),len(ts[j]))/max(len(ts[i]),len(ts[j]))
  if ratio<.77:continue
  shared=len(sets[i]&sets[j]);jac=shared/len(sets[i]|sets[j]);contain=shared/min(len(sets[i]),len(sets[j]))
  if jac>=.82 or (contain>=.93 and ratio>=.82):candidates.append((float(dis),i,j,jac,contain))
# Require each merge to pass similarity against a fixed cluster representative; avoid single-link chain drift.
for dis,i,j,jac,contain in sorted(candidates):
 a,b=find(i),find(j)
 if a==b:continue
 repa,repb=sets[a],sets[b]
 if not repa or not repb:continue
 share=len(repa&repb);j2=share/len(repa|repb);c2=share/min(len(repa),len(repb));ratio=min(len(ts[a]),len(ts[b]))/max(len(ts[a]),len(ts[b]))
 if j2>=.82 or (c2>=.93 and ratio>=.82):
  # The representative with the lower export position is stable under reruns.
  lo,hi=sorted([a,b]);parent[hi]=lo;edges.append({'a':rs[i]['doc_id'],'b':rs[j]['doc_id'],'method':'near_text_6gram','jaccard':round(jac,5),'shorter_coverage':round(contain,5),'cosine_distance':round(dis,5)})
groups=collections.defaultdict(list)
for i in range(N):groups[find(i)].append(i)
families=[]
for ids in groups.values():
 rep=min(ids);fid='F'+rs[rep]['doc_id'][1:];ret=not rs[rep]['decision'].startswith('EXCLUDE')
 for i in ids:rs[i]['family_id']=fid;rs[i]['canonical_doc_id']=rs[rep]['doc_id'];rs[i]['is_family_representative']=i==rep;rs[i]['family_size']=len(ids)
 families.append({'family_id':fid,'canonical_doc_id':rs[rep]['doc_id'],'year':rs[rep]['year'],'retained':ret,'members':[rs[i]['doc_id'] for i in ids],'size':len(ids),'titles':[rs[i]['title'] for i in ids]})
(P/'familied_stage.json').write_text(json.dumps(rs,ensure_ascii=False),encoding='utf-8');(P/'families.json').write_text(json.dumps(families,ensure_ascii=False,indent=2),encoding='utf-8');(P/'family_links.json').write_text(json.dumps(edges,ensure_ascii=False,indent=2),encoding='utf-8')
print('FAMILIES',len(families),'RETAINED',sum(f['retained'] for f in families))
print('YEAR',[(y,sum(r['year']==y and not r['decision'].startswith('EXCLUDE') for r in rs),sum(f['year']==y and f['retained'] for f in families)) for y in [2025,2026]])
for f in sorted(families,key=lambda x:x['size'],reverse=True)[:18]:print(f['size'],f['members'],f['titles'][:3])
