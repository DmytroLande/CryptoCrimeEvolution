"""Audit coding v1.0 for the supplied InfoStream export; decisions are not independent expert validation."""
import json,re,collections,hashlib,html,zipfile,sys
from pathlib import Path
from docx import Document
ROOT=Path(__file__).resolve().parent
INPUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'upload'/'2011(3).docx'
DOC=Document(INPUT)
records=[];cur=None
for pi,p in enumerate(DOC.paragraphs,1):
 for li,line in enumerate(p.text.splitlines(),1):
  if line.strip()=='***':
   if cur:records.append(cur)
   cur={'number':len(records)+1,'paras':[]}
  elif cur:cur['paras'].append({'paragraph':pi,'line':li,'text':line})
if cur:records.append(cur)
context={15,16,31,211};supplement={32,33};incidental={19,20};related={49}
family_sets=[('F029',[29,30],29,'Майже однаковий передрук Newsweek у Khaleej Times'),('F032',[32,33],33,'Ідентичний опублікований IRC-журнал'),('F035',[35,36],35,'Майже однакові версії матеріалу James Ball'),('F054',[54,118,165,195,196],195,'Синдикований матеріал AFP про гаманці та Symantec'),('F082',[82,88],82,'Дві версії того самого матеріалу DailyTech; збережено розширену'),('F203',[203,204],204,'Ідентичний текст Guardian та Observer')]
fam={n:(f,canon,why) for f,ns,canon,why in family_sets for n in ns}
EVENTS=[
('E01','Silk Road як ринок із платежами Bitcoin','Тривалий процес; запуск у лютому згідно з повідомленнями, не перевірений окремо',[210,208,209],'reported_practice','Оплата незаконних товарів; TOR описаний як засіб доступу. Кримінальний контекст стосується описаних товарів, а не Bitcoin загалом.'),
('E02','Звернення сенаторів щодо Silk Road','Червень 2011; пресконференція та лист згруповані як епізод реагування',[206,207,208,209,203,204,200],'reported_response','Вимога вжити заходів не означає, що ринок було закрито або активи вилучено.'),
('E03','Заява Allinvain про втрату 25 000 BTC','Червень 2011; ранній запис у корпусі 16 червня',[198,199,34,40],'unverified_claim','The Register прямо вказує на неможливість перевірки. Не підсумовувати заявлену суму зі збитками Mt. Gox.'),
('E04','Infostealer.Coinbit та викрадення файлів гаманців','Червень 2011; найраніша дата запису 17 червня',[197,137,195,196,118,165,54,27],'reported_security_finding','Вилучення файлу гаманця; основа багатьох повідомлень — результати Symantec. Це сімейство шкідливого ПЗ, а не число заражень.'),
('E05','Trojan.NSIS.Miner.a та прихований майнінг','Кінець червня за ретроспективним описом; записи 1 липня та 16 серпня',[27,14],'reported_security_finding','Зловмисний модуль запускає легітимний майнер на скомпрометованій машині. Дата публікації відрізняється від часу спостереження.'),
('E06','Stealthcoin як рання згадка прихованого майнінгу','Приблизно квітень за ретроспективною згадкою 1 липня',[27],'single_source_retrospective','Окрема назва й часовий орієнтир з одного матеріалу; не вважати встановленою датою першого застосування.'),
('E07','Компрометація та призупинення торгів Mt. Gox','Червень 2011; повідомлення містять посилання на 19 червня',[82,88,46,35,36,37,38,34,40,39],'reported_incident_with_conflicting_details','Розбіжності щодо способу доступу, обсягу коштів і атрибуції; доведеність переказу та фактичного фіатного виведення не встановлена цим аудитом.'),
('E08','Trojan.Badminer та використання GPU','Серпень 2011; записи 16 та 18 серпня',[12,13],'reported_finding_with_technical_conflict','DailyTech описує майнінг, The Register змішує опис майнінгу зі зламом гаманців. Останній механізм не приймається як перевірений.'),
('E09','Kelihos та операція з порушення керування ботнетом','Вересень 2011; запис 28 вересня',[10],'reported_response_and_capability','Згадано збирання файлів гаманців і судовий захід щодо доменів. Не прирівнювати це до вилучення Bitcoin.'),
('E10','DevilRobber та поєднання майнінгу з викраденням гаманців','Кінець жовтня — початок листопада; перше виявлення в тексті пов’язане з 29 жовтня',[6,7,8],'reported_security_finding','Три публікації про те саме сімейство, які посилаються на Sophos та Intego. Не три незалежні атаки.'),
('E11','Відмова EFF від приймання Bitcoin','Червень 2011; запис 22 червня',[39],'reported_noncriminal_policy_change','Правова невизначеність і ризик сприйняття пожертв як схвалення. Не позначається як кримінальна подія.'),
('E12','Запуск Camp BX та заявлені заходи захисту','Липень 2011; запис 11 липня',[25],'reported_launch_and_self_declared_controls','Безпека й комплаєнс описані переважно словами представника біржі; ефективність не вимірювалася.'),
('E13','Дослідження простежуваності в інтерв’ю Martin Harrigan','Липень 2011; запис 29 липня',[17],'reported_research_explanation','Описано можливість зв’язування адрес за пізнішими операціями. Це не повідомлення про успішну поліцейську деанонімізацію.'),
('E14','Мобільний гаманець Bitcoin для Android','Липень 2011; запис 8 липня',[26],'reported_legitimate_infrastructure','Фоновий розвиток легальної інфраструктури; згадки попередніх злочинів не роблять запуск кримінальним.')]
PRACTICES=[
('P01','Bitcoin як засіб оплати підпільних послуг',[9,11],'Оглядові твердження; без окремо ідентифікованих угод і доведених обсягів.'),
('P02','Зловживання поверненнями платежів PayPal під час купівлі BTC',[202],'Опис практики в аналітичному матеріалі; не реєстр підтверджених випадків. Окремо від переліку легальних платіжних каналів.'),
('P03','Пожертви на підтримку Topiary та Anonymous',[16,50],'Правовий статус пожертв не встановлено; не прирівнювати до фінансування злочину.'),
('P04','Публікація нібито IRC-журналів LulzSec',[32,33],'Автентичність не перевірена; окремий допоміжний шар, не основна статистика повідомлень.')]
notes={
6:'DevilRobber; описано два механізми, а не два незалежні інциденти.',7:'DevilRobber; дата в заголовку 31 жовтня, метадані експорту 1 листопада.',8:'DevilRobber; посилання на Sophos та Intego.',9:'Огляд платних хакерських послуг; не одинична угода.',10:'Kelihos; спроможність збирати гаманці, не число викрадених BTC.',11:'Огляд підпільних розрахунків; 63% стосується ширшого набору онлайн-валют, не Bitcoin окремо.',12:'Badminer; основний опис — несанкціонований майнінг.',13:'Badminer; технічно неоднозначне змішування майнінгу й підбору ключів.',14:'Огляд Kaspersky; ретроспективне повідомлення про майнер та викрадення гаманців.',15:'Легітимний інструмент тестування; наявність можливості не доводить злочинного використання.',16:'Пожертви; кримінальний статус платежів не встановлений.',17:'Інтерв’ю про дослідження простежуваності; не правоохоронна операція.',18:'Огляд екосистеми з явним описом злочинних механізмів і легального використання.',19:'Bitcoin лише в аналогії із захистом Mt. Gox; основний інцидент — Booz Allen/AntiSec.',20:'Версія D2011-019; те саме побіжне порівняння.',25:'Біржа Camp BX; безпека та комплаєнс як заяви її представника.',26:'Легальний мобільний гаманець; у тексті також описано попередні інциденти.',27:'Coinbit, NSIS.Miner.a і ретроспективна згадка Stealthcoin.',29:'Огляд; авторські та політичні оцінки не є доказами відмивання.',30:'Передрук D2011-029; різні часові позначки збережено.',31:'Словник; твердження про непростежуваність кодується як уявлення джерела.',32:'Великий опублікований IRC-журнал; автентичність не перевірена.',33:'Ідентичний журнал D2011-032; окремий допоміжний шар.',34:'Огляд із кількома подіями та неперевіреними твердженнями; суми не агрегуються.',35:'Mt. Gox; атрибуція LulzSec оспорюється, механізм компрометації суперечливий.',36:'Версія D2011-035.',37:'Дайджест; лише фрагмент LulzSec релевантний і повторює D2011-038.',38:'UPI посилається на Guardian; не незалежне підтвердження атрибуції.',39:'EFF та відновлення Mt. Gox; розділяти події.',40:'Авторська колонка; наявні інциденти й політичні інтерпретації.',46:'Mt. Gox; точний механізм і розмір збитку в тексті невідомі.',49:'Bitcoin лише в Related Articles; основна новина про пограбування банку.',50:'Пожертви та нібито журнали; сам автор застерігає щодо автентичності.',54:'Передрук AFP про Symantec; не нове зараження.',82:'Розширена версія D2011-088; внутрішні суперечності щодо чисел.',88:'Попередня версія D2011-082; не додаткова атака.',118:'Матеріал AFP, повтор публікації про гаманці.',137:'Coinbit, повідомлення про виявлення, не перша історична крадіжка.',165:'Перероблений передрук AFP.',195:'AFP про Symantec; представник сімейства передруків.',196:'AFP у Bangkok Post, повтор вступного речення.',197:'Coinbit; дані приватних ключів, не файл балансу.',198:'Заява Allinvain; джерело прямо зазначає неможливість перевірки.',199:'Оспорювана атрибуція переказу LulzSec; не доказ відповідальності.',200:'Авторська політична інтерпретація; лист сенаторів цитовано як окремий факт повідомлення.',201:'Причинний зв’язок між зверненням сенаторів і курсом не встановлений.',202:'Огляд; є опис шахрайських повернень PayPal і платіжних каналів, але немає реєстру угод.',203:'Текст Guardian/Observer про Silk Road; одне сімейство.',204:'Ідентичний текст D2011-203.',205:'Ринкова волатильність, платіжні канали та аргументи про анонімність; не окремий злочин.',206:'Вимоги сенаторів і можливе регулювання обмінних каналів.',207:'Reuters; обмінні банківські рахунки як потенційна точка впливу, не виконаний арешт.',208:'Silk Road і пресконференція; не всі технічні твердження джерела приймаються як істинні.',209:'Silk Road і вимога Schumer; статус вимоги відокремлений від результату.',210:'Опис незаконного ринку; текст містить помилкові або надмірні твердження про анонімність.',211:'Легальна технологія та загальні правові ризики; без окремої кримінальної події.',212:'Огляд Forbes; згадано незаконні покупки та легальне використання.'}
for d in records:
 n=d['number'];d['doc_id']=f'D2011-{n:03}'
 ls=[p for p in d['paras'] if p['text'].strip()];d['title']=ls[0]['text'].strip()
 metas=[(j,re.match(r'^(.+?) (2011\.\d\d\.\d\d \d\d:\d\d)\s*$',p['text'])) for j,p in enumerate(d['paras'])];j,m=[(j,m) for j,m in metas if m][-1]
 d['source_label']=m[1];d['export_timestamp']=m[2];d['export_day']=m[2][:10].replace('.','-');d['url']=next((p['text'].strip() for p in d['paras'][j+1:] if p['text'].strip().startswith('http')),'')
 ps=d['paras'][:j];d['title_anchor']={'paragraph':ls[0]['paragraph'],'line':ls[0]['line']}
 if d['source_label']=='BusinessWeek':
  start=next((i+1 for i,p in enumerate(ps) if 'Business Exchange E-mail Print' in p['text']),0)
  end=next((i for i in range(start,len(ps)) if re.match(r'^(--|To contact|READER DISCUSSION|Most Popular|Business Exchange E-mail Print)',ps[i]['text'])),len(ps))
  body=[p for p in ps[start:end] if not p['text'].startswith('More From Businessweek')]
  assert not any(re.search('bitcoin',p['text'],re.I) for p in body),d['doc_id']
  d['decision']='EXCLUDE_NAVIGATION';d['reason']='Bitcoin відсутній в основному тексті; збіг у рекомендаціях/навігації.'
 elif n in incidental:d['decision']='EXCLUDE_INCIDENTAL';d['reason']=notes[n];body=ps
 elif n in related:d['decision']='EXCLUDE_RELATED';d['reason']=notes[n];body=ps[:next((i for i,p in enumerate(ps) if p['text'].startswith('Related Articles:')),len(ps))]
 else:
  d['decision']='CONTEXT' if n in context else 'SUPPLEMENT' if n in supplement else 'MAIN'
  d['reason']=notes[n];body=ps
  cutoff=next((i for i,p in enumerate(body) if re.match(r'^(See Also:|See more about:|Follow @|Special Offer:|© Copyright)',p['text'])),len(body));body=body[:cutoff]
 d['family_id'],canon,d['family_note']=fam.get(n,(f'F{n:03}',n,'Окремий запис; незалежність походження не припускається.'))
 d['canonical_doc_id']=f'D2011-{canon:03}';d['is_family_representative']=n==canon
 d['related_event_ids']=[eid for eid,_,_,ns,_,_ in EVENTS if n in ns]
 d['practice_ids']=[pid for pid,_,ns,_ in PRACTICES if n in ns]
 d['partial_overlap_doc_ids']=['D2011-038'] if n==37 else ['D2011-037'] if n==38 else []
 matches=[p for p in (ps if d['decision'].startswith('EXCLUDE') else body) if re.search(r'bitcoin|coinbit|badminer|devilrobber|silk road',p['text'],re.I)]
 # Evidence locations refer to exact paragraph/line in original DOCX, not to page numbers.
 d['evidence']=[{'paragraph':p['paragraph'],'line':p['line'],'quote':p['text'][:900]} for p in matches[:4]]
 patterns={'E01':r'Silk Road|illegal drugs','E02':r'senators|Schumer|letter|Manchin','E03':r'Allinvain|25,000|verify|hoax','E04':r'Coinbit|CoinBit|wallet','E05':r'NSIS|Gostev|late June|bcm','E06':r'Stealthcoin','E07':r'Mt.? ?Gox|MtGox|auditor|compromised','E08':r'Badminer|GPU|mining','E09':r'Kelihos|Bitcoin wallets|court order','E10':r'DevilRobber|wallet|miner','E11':r'no longer accept|reversed its stance|money laundering','E12':r'Camp BX|comply|regulator','E13':r'link|anonymous|transaction','E14':r'Android|Wednesday|app'}
 d['event_evidence']=[]
 for eid in d['related_event_ids']:
  hits=[p for p in body if re.search(patterns[eid],p['text'],re.I)]
  for p in hits[:3]:d['event_evidence'].append({'event_id':eid,'paragraph':p['paragraph'],'line':p['line'],'quote':p['text'][:1100]})
 d['body']= '\n'.join(p['text'] for p in body) if d['decision'] in ('MAIN','CONTEXT') else None
 del d['paras']
counts=collections.Counter(d['decision'] for d in records)
assert len(records)==212 and sum(counts.values())==212
retained=[d for d in records if not d['decision'].startswith('EXCLUDE')]
family_ids={d['family_id'] for d in retained}
events=[dict(event_id=i,title=t,time_description=tm,evidence_doc_ids=[f'D2011-{n:03}' for n in ns],epistemic_status=st,interpretation=note) for i,t,tm,ns,st,note in EVENTS]
for ev in events:
 ev['evidence']=[dict(doc_id=d['doc_id'],**a) for d in records for a in d['event_evidence'] if a['event_id']==ev['event_id']]
practices=[dict(practice_id=i,title=t,evidence_doc_ids=[f'D2011-{n:03}' for n in ns],limitation=note) for i,t,ns,note in PRACTICES]
edges_data=[
('Bitcoin','pays_for','Illegal goods on Silk Road',[210,208,209],'reported'),('Silk Road','accessed_via','TOR',[210,208,209],'reported'),('Mt. Gox','exchanges','Bitcoin and fiat',[207,34,38,40],'reported'),('Bitcoin wallet','contains','Private keys',[197],'reported'),('Coinbit','exfiltrates','Bitcoin wallet',[137,197,27],'reported'),('NSIS.Miner.a','uses_without_consent','Victim computing resources',[27,14],'reported'),('Stealthcoin','uses','Compromised machines',[27],'retrospective_single_source'),('Badminer','mines','Bitcoin',[12],'reported_conflicting_other_source'),('DevilRobber','mines','Bitcoin',[6,7,8],'reported'),('DevilRobber','steals','Bitcoin wallet',[6,7,8],'reported'),('Kelihos','collects','Bitcoin wallet',[10],'reported'),('US senators','request_action_against','Silk Road',[206,207,208,209],'reported_response'),('Harrigan interview','explains','Retrospective address linking',[17],'reported_research'),('Coinbit','reported_by','Symantec',[137,197],'reported_provenance'),('Camp BX','declares','Security and compliance controls',[25],'self_declared'),('EFF','stops_accepting','Bitcoin donations',[39],'reported_policy'),('Mt. Gox','suspends','Trading after compromise',[82,88,46],'reported'),('Underground services','accept_payment_in','Bitcoin',[9,11],'overview_claim'),('PayPal purchases of BTC','exposed_to','Fraudulent chargeback claims',[202],'overview_claim')]
edges=[{'edge_id':f'R{i:02}','source':a,'relation':r,'target':b,'evidence_doc_ids':[f'D2011-{n:03}' for n in ns],'status':st} for i,(a,r,b,ns,st) in enumerate(edges_data,1)]
for e in edges:e['publication_families']=len({records[int(s[-3:])-1]['family_id'] for s in e['evidence_doc_ids']})
query='bitcoin & (crime | criminal | illegal | illicit | laundering | drugs | (Silk~Road) | darknet | cashout)'
summary={'schema_version':'1.0','input_name':INPUT.name,'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),'query_from_export':query,'record_count':len(records),'decision_counts':dict(counts),'retained_records':len(retained),'retained_publication_families':len(family_ids),'family_collapses':len(retained)-len(family_ids),'source_labels_all':len({d['source_label'] for d in records}),'source_labels_retained':len({d['source_label'] for d in retained}),'all_metadata_range':[min(d['export_day'] for d in records),max(d['export_day'] for d in records)],'retained_metadata_range':[min(d['export_day'] for d in retained),max(d['export_day'] for d in retained)],'all_by_month':dict(sorted(collections.Counter(d['export_day'][:7] for d in records).items())),'retained_by_month':dict(sorted(collections.Counter(d['export_day'][:7] for d in retained).items())),'event_process_cards':len(events),'practice_cards':len(practices),'seed_graph_edges':len(edges),'validation':'Один аналітичний прохід із програмною перевіркою узгодженості; незалежна експертна валідація та перевірка зовнішніх першоджерел не виконувалися.'}
for fn,data in [('audit_212.json',records),('events_14.json',events),('practices_4.json',practices),('semantic_edges_19.json',edges),('summary.json',summary)]:
 (ROOT/fn).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'clean_main_context_52.jsonl').write_text('\n'.join(json.dumps(d,ensure_ascii=False) for d in records if d['decision'] in ('MAIN','CONTEXT'))+'\n',encoding='utf-8')
# A compact standalone audit surface for human review. No network assets or executable source content.
esc=html.escape
status_names={'MAIN':'Основний тематичний масив','CONTEXT':'Контекст','SUPPLEMENT':'Допоміжний журнал','EXCLUDE_NAVIGATION':'Виключено — навігація','EXCLUDE_INCIDENTAL':'Виключено — побіжне порівняння','EXCLUDE_RELATED':'Виключено — пов’язані матеріали'}
parts=['<!doctype html><html lang="uk"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Аудит корпусу за 2011 рік</title><style>body{font:16px/1.55 system-ui;margin:32px auto;max-width:1100px;padding:0 20px;color:#172333}h1,h2,h3{color:#111}table{border-collapse:collapse;width:100%}td,th{padding:9px;border:1px solid #ccd4dc;text-align:left;vertical-align:top}th{background:#edf1f5}input,select{font:inherit;padding:9px;margin:8px 8px 12px 0;max-width:90%}summary{cursor:pointer;font-weight:650}details{border-bottom:1px solid #dce1e6;padding:13px 0}blockquote{margin-left:15px;border-left:3px solid #ddd;padding-left:15px}small{color:#516074}pre{white-space:pre-wrap;font:14px/1.55 system-ui}.badge{background:#edf1f5;padding:3px 7px;border-radius:4px}a{overflow-wrap:anywhere}</style><body><h1>Аудит корпусу за 2011 рік</h1><p>212 записів; 158 виключено; 54 залишено у трьох шарах; 45 сімейств публікацій. Це не 45 незалежних джерел і не 45 злочинів.</p><p>Пошук у таблиці нижче охоплює заголовки, примітки та цитати. Оригінальні матеріали не перевірялися через інтернет. Дати — часові позначки експорту.</p><h2>Події та процеси</h2>']
for ev in events:parts.append('<details><summary>'+esc(ev['event_id']+' '+ev['title'])+'</summary><p>'+esc(ev['time_description'])+'</p><p>'+esc(ev['interpretation'])+'</p><p>'+', '.join('<a href="#'+s+'">'+s+'</a>' for s in ev['evidence_doc_ids'])+'</p></details>')
parts.append('<h2>Початковий семантичний граф</h2><p>19 вручну відібраних типізованих зв’язків; це початкове кодування, а не автоматично обчислена повна мережа.</p><table><tr><th>Суб’єкт</th><th>Зв’язок</th><th>Об’єкт</th><th>Свідчення</th></tr>')
for e in edges:parts.append('<tr>'+''.join('<td>'+esc(str(e[k]))+'</td>' for k in ['source','relation','target'])+'<td>'+', '.join('<a href="#'+s+'">'+s+'</a>' for s in e['evidence_doc_ids'])+'</td></tr>')
parts.append('</table><h2>Реєстр усіх 212 записів</h2><label>Пошук <input id="q" placeholder="Coinbit, Mt. Gox, D2011-197…"></label><select id="filter"><option value="">Усі рішення</option>'+''.join('<option value="'+k+'">'+v+'</option>' for k,v in status_names.items())+'</select><p id="n"></p>')
for d in records:
 parts.append('<details class="record" id="'+d['doc_id']+'" data-status="'+d['decision']+'"><summary>'+esc(d['doc_id']+' · '+d['export_day']+' · '+d['title'])+'</summary><p><span class="badge">'+status_names[d['decision']]+'</span> '+esc(d['source_label'])+'</p><p>'+esc(d['reason'])+'</p><p>Сімейство '+d['family_id']+'; представник '+d['canonical_doc_id']+'. '+esc(d['family_note'])+'</p><p><a href="'+esc(d['url'],quote=True)+'">'+esc(d['url'])+'</a></p>')
 for ev in d['evidence']+d['event_evidence']:parts.append('<blockquote>'+esc(ev['quote'])+'<br><small>Абзац '+str(ev['paragraph'])+', рядок '+str(ev['line'])+' у вихідному DOCX</small></blockquote>')
 parts.append('</details>')
parts.append('<script>const rs=[...document.querySelectorAll(".record")],q=document.getElementById("q"),f=document.getElementById("filter");function run(){let n=0;for(const r of rs){const ok=(!f.value||r.dataset.status===f.value)&&r.textContent.toLowerCase().includes(q.value.toLowerCase());r.hidden=!ok;if(ok)n++}document.getElementById("n").textContent="Показано записів: "+n}q.addEventListener("input",run);f.addEventListener("change",run);window.addEventListener("hashchange",()=>{const r=document.getElementById(location.hash.slice(1));if(r&&r.classList.contains("record")){q.value="";f.value="";run();r.open=true;r.scrollIntoView({block:"start"})}});run();</script></body></html>')
(ROOT/'Audit_2011.html').write_text(''.join(parts),encoding='utf-8')
# GraphML exports exactly the listed seed relations; no inferred transaction edges.
import xml.etree.ElementTree as ET
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns);gr=ET.Element('{'+ns+'}graphml')
for key,domain in [('label','node'),('relation','edge'),('evidence','edge'),('status','edge')]:ET.SubElement(gr,'{'+ns+'}key',{'id':key,'for':domain,'attr.name':key,'attr.type':'string'})
g=ET.SubElement(gr,'{'+ns+'}graph',{'id':'G2011','edgedefault':'directed'});nodes=sorted({e[k] for e in edges for k in ['source','target']});nodeid={s:f'n{i}' for i,s in enumerate(nodes)}
for s in nodes:nd=ET.SubElement(g,'{'+ns+'}node',{'id':nodeid[s]});ET.SubElement(nd,'{'+ns+'}data',{'key':'label'}).text=s
for ed in edges:
 ee=ET.SubElement(g,'{'+ns+'}edge',{'id':ed['edge_id'],'source':nodeid[ed['source']],'target':nodeid[ed['target']]})
 for k,val in [('relation',ed['relation']),('evidence',','.join(ed['evidence_doc_ids'])),('status',ed['status'])]:ET.SubElement(ee,'{'+ns+'}data',{'key':k}).text=val
ET.ElementTree(gr).write(ROOT/'Semantic_2011.graphml',encoding='utf-8',xml_declaration=True)
print(json.dumps(summary,ensure_ascii=False,indent=2))
