from pathlib import Path
import json,re,collections
P=Path(__file__).resolve().parent;rs=json.loads((P/'screened_stage.json').read_text());overrides={}
def setd(ns,decision,why):
 for n in ns:overrides[n]=(decision,why)
setd([66,110,166,167,168,242,298,351,424,428,454,553,575,582,618,638,643,689,776,780,836,891,900,923,969,973,979,996,1013,1024,1117,1133,1198,1319,284], 'EXCLUDE_NAVIGATION','Адресно перевірено згадку — стороння рекомендація, відео, сервісний блок або інший заголовок.')
setd([4,8,9,199,227,265,315,320,345,357,384,417,438,562,581,611,626,627,747,815,824,828,829,831,876,882,884,930,932,945,959,994,1020,1023,1046,1072,1136,1139,1157,1172,1211,440,739,835,960,1069,623], 'EXCLUDE_INCIDENTAL','Побіжна згадка, порівняння, фінансовий дисклеймер, бібліографія або загальна blockchain-тема без предметного механізму дослідження.')
setd([21,171,185,189,204,218,253,299,303,314,317,344,403,405,415,453,476,566,571,655,674,712,740,754,755,804,822,1079,228,238,348,499,628], 'CONTEXT','Перевірений контекст, аналогія, заява, інфраструктура або ширша подія; не достатня підстава для підрахунку окремого злочину.')
setd([54,58], 'SUPPLEMENT','Річний огляд із тематичним фрагментом Twitter; не окрема нова подія.')
setd([176,239,243,727], 'MAIN','Адресно перевірений змістовний фрагмент про майнінг, викрадення, оплату чи контроль обмінної інфраструктури.')
# Restore article continuations where an inline related-link boundary cut the article early.
for n in [141,175,250,287]:
 r=rs[n-1];ps=r['content_paragraphs'];clean=[]
 for p in ps:
  if re.search(r'Previous and related coverage',p['text'],re.I):
   # Text before an embedded boundary belongs to the article; keep its source paragraph intact for provenance.
   if not p['text'].strip().lower().startswith('previous and related coverage'):clean.append(p)
   break
  if not re.match(r'^(See also:|Related (Articles|Stories)|Most Read)',p['text'],re.I):clean.append(p)
 r['body_paragraphs']=clean;r['body']='\n'.join(p['text'] for p in clean);r['recovery_note']='Reviewed restoration after premature inline-link cut; original paragraphs preserved.'

# Externally visible publication type is determined from the export's source label, not authority scores.
official={'Federal Bureau of Investigation','US Department of State','U.S. Department of Homeland Security','U.S. Department of the Treasury','Canada News Centre','INTERPOL','EU European Commission'}
TAG_RULES={
'T_DARK_MARKETS':('Нелегальні онлайн-ринки',r'\bsilk road\b|\bsheep marketplace\b|\bblack market\b|\bdarknet market|\bdark web market'),
'T_WALLET_THEFT':('Викрадення гаманців або активів',r'(?:steal\w*|stolen|theft|exfiltrat\w*).{0,150}(?:wallet|bitcoin|private key)|(?:wallet|bitcoin|private key).{0,150}(?:steal\w*|stolen|theft|exfiltrat\w*)'),
'T_UNAUTH_MINING':('Ботнетний або несанкціонований майнінг',r'(?:botnet|malware|trojan|infected|compromised).{0,160}(?:mining|mine bitcoins?|miner)|(?:mining|mine bitcoins?|miner).{0,160}(?:botnet|malware|trojan|infected|compromised)'),
'T_MIXING_PRIVACY':('Змішування та інструменти приватності',r'\bmixers?\b|\bmixing\b|\btumbl\w*\b|coinjoin|bit.?laundry|bitcoin laundry|bitcoin fog|dark wallet|zerocoin|darksend'),
'T_RANSOMWARE':('Програми-вимагачі',r'cryptolocker|crypto.?wall|\bransomware\b|\breveton\b|\bransom\b'),
'T_EXCHANGE_CASHOUT':('Обмін і платіжні канали',r'cash[ -]?out|\bexchangers?\b|bitcoin exchange|exchange.{0,35}bitcoin|convert.{0,70}(?:bitcoin|dollars|fiat)|\bbitinstant\b|\blocalbitcoins\b'),
'T_REGULATION':('Ідентифікація та регуляторні механізми',r'anti.money.launder|\bAML\b|\bKYC\b|\bFinCEN\b|\bBitLicense\b|money.transmitt|money.services.business|account.verif|identity.verif'),
'T_SEIZURE':('Вилучення та конфіскація',r'\bseiz\w*\b|\bconfisc\w*\b|\bforfeit\w*\b|\bauction\w*\b'),
'T_TRACE':('Простежуваність',r'blockchain|block chain|traceab|tracing|taint analysis|de.?anonym|transaction.{0,60}track|track.{0,60}transaction'),
'T_ALT_ASSETS':('Інші активи та протоколи приватності',r'\b(?:darkcoin|litecoin|dogecoin|monero|zerocoin|ethereum|zcash|cloakcoin|tether|usdt|stablecoin|nem)\b')}
TAG_RULES.update({
'T_CHAIN_HOPPING':('Міжактивні переходи та їх приховування',r'chain[ -]hopp|blockchain[ -]hopp|peel[ -]chains?'),
'T_OTC_MENTION':('OTC згадка з неоднозначним значенням',r'\bOTC\b|over.the.counter'),
'T_P2P_MENTION':('P2P згадка з неоднозначним значенням',r'\bP2P\b|peer.to.peer'),
'T_STABLECOINS':('Стейблкоїни та їхній контекст',r'\bstablecoins?\b|\bTether\b|\bUSDT\b|\bDai\b'),
'T_DEFI':('DeFi та децентралізований обмін',r'\bDeFi\b|decentralized finance|decentralised finance|\bDEX\b|flash.loan'),
'T_TRAVEL_RULE':('Travel rule та постачальники послуг',r'travel rule|\bVASPs?\b'),
'T_BANK_CASH_STAGE':('Кандидати банківської або готівкової стадії',r'convert.{0,90}fiat|fiat.{0,70}convert|bank account|pre.paid.*card|\bATMs?\b')})
for r in rs:
 n=r['export_position'];r['decision_origin']='rule_v2';r['analyst_note']=''
 if r['source_label']=='CyberWire' and not r['decision'].startswith('EXCLUDE'):
  r['decision']='SUPPLEMENT';r['reason']='Дайджест і перелік посилань; тематичні фрагменти збережено, але не прирівняно до самостійних першоджерел.';r['decision_origin']='genre_rule'
 if r['source_label']=='PR Newswire' and not r['decision'].startswith('EXCLUDE'):
  r['decision']='CONTEXT';r['reason']='Поширений пресреліз або рекламний матеріал; заяви про можливості чи ефективність потребують незалежної перевірки.';r['decision_origin']='genre_rule'
 if r['source_label']=='ArXiv' and not r['decision'].startswith('EXCLUDE'):
  r['decision']='CONTEXT';r['reason']='Дослідницька публікація; методичний контекст, а не новий кримінальний інцидент.';r['decision_origin']='genre_rule'
 if re.search(r'central bank digital|digital yuan|Libra|Diem|CBDC|stablecoin|Tether|crypto.*(?:price|surge|rally)|bitcoin.*(?:price|surge|rally)',r['title'],re.I) and not re.search(r'launder|criminal|fraud|ransom|hack|red.flag|sanction',r['title'],re.I):
  if not r['decision'].startswith('EXCLUDE'):
   r['decision']='CONTEXT';r['reason']='Інфраструктурний, ринковий або регуляторний контекст; окрему доведену кримінальну операцію не встановлює.';r['decision_origin']='context_title_rule'
 if n in overrides:r['decision'],r['reason']=overrides[n];r['decision_origin']='analyst_override_from_source_fragment'
 if r['decision']=='REVIEW':r['decision']='CONTEXT';r['reason']='Одинична змістовна згадка, збережена як контекст без підрахунку окремої кримінальної події.';r['decision_origin']='conservative_context_assignment'
 if r['decision']=='EXCLUDE_NO_CRYPTO':r['decision']='EXCLUDE_NO_TOPIC'
 body=r['body'];explicit=re.search(r'bitcoin|crypto[ -]?currenc|litecoin|darkcoin|dogecoin|monero|zerocoin',body,re.I)
 r['asset_scope']='centralized_payment_primary' if r['decision']=='ADJACENT_PAYMENT' else 'explicit_crypto' if explicit else 'virtual_currency_unspecified' if re.search(r'(?:virtual|digital)[ -]currenc',body,re.I) else 'case_context_or_other'
 r['source_type']='official_institution' if r['source_label'] in official else 'promotional_release' if r['source_label']=='PR Newswire' else 'research_source' if r['source_label'] in {'ArXiv','NATO CCDCOE','Trend Micro','Center for Strategic and International Studies','Brookings','Atlantic Council'} else 'media_or_other'
 r['mixed_content']=bool(re.search(r'^home$|news.*(?:recap|digest)|coverage advisory|as it happened|^technology home$|^opinion home$|^business this week$|^letters:|^biz briefs$|^latest showbiz$|TWEET$',r['title'],re.I))
 r['tags']=[];r['tag_evidence']=[]
 if not r['decision'].startswith('EXCLUDE'):
  for code,(label,pattern) in TAG_RULES.items():
   found=[p for p in r['body_paragraphs'] if re.search(pattern,p['text'],re.I)]
   if found:
    r['tags'].append(code)
    for p in found[:2]:
     ma=re.search(pattern,p['text'],re.I);start=max(0,ma.start()-140);r['tag_evidence'].append({'tag':code,'paragraph':p['paragraph'],'line':p['line'],'start_char':start,'quote':p['text'][start:start+650]})
 r['evidence']=[]
 for p in r['body_paragraphs']:
  if re.search(r'bitcoin|crypto[ -]?currenc|virtual.currenc|liberty reserve|liberty reverse|coinjoin|dark wallet|darkcoin|ransomware',p['text'],re.I):
   r['evidence'].append({'paragraph':p['paragraph'],'line':p['line'],'quote':p['text'][:1000]})
   if len(r['evidence'])==4:break
rkeep=[r for r in rs if not r['decision'].startswith('EXCLUDE')]
(P/'adjudicated_stage.json').write_text(json.dumps(rs,ensure_ascii=False),encoding='utf-8')
(P/'codebook.json').write_text(json.dumps({'version':'1.0','tags':{k:{'label':v[0],'pattern':v[1]} for k,v in TAG_RULES.items()},'meaning':'Це лексичні індикатори тем у текстах, не доведені події чи обсяги злочинності. Час згадки не дорівнює часу виникнення механізму.','overrides':{str(k):{'decision':v[0],'reason':v[1]} for k,v in overrides.items()}},ensure_ascii=False,indent=2),encoding='utf-8')
print({y:dict(collections.Counter(r['decision'] for r in rs if r['year']==y)) for y in [2018,2019,2020]})
print('UNREVIEWED SINGLE HITS')
for r in rs:
 if r['decision_origin']=='conservative_context_assignment':print(r['export_position'],r['title'])
