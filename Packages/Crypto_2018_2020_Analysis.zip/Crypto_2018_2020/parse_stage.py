from docx import Document
from pathlib import Path
import re,json,collections,hashlib,sys
P=Path(__file__).resolve().parent;inp=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else P.parent/'upload'/'2020.docx';D=Document(inp);rs=[];cur=None
for pi,p in enumerate(D.paragraphs,1):
 for li,line in enumerate(p.text.splitlines(),1):
  if line.strip()=='***':
   if cur:rs.append(cur)
   cur={'export_position':len(rs)+1,'paragraphs':[]}
  elif cur:cur['paragraphs'].append({'paragraph':pi,'line':li,'text':line})
if cur:rs.append(cur)
counts=collections.Counter()
for r in rs:
 ps=r['paragraphs'];metas=[(i,re.match(r'^(.+?)\s+(20\d\d\.\d\d\.\d\d)\s+(\d\d:\d\d)\s*$',p['text'].strip())) for i,p in enumerate(ps)];metas=[(i,m) for i,m in metas if m]
 if not metas:print('NO META',r['export_position'],str(ps)[:200]);continue
 i,m=metas[-1];r['source_label']=m[1];r['export_date']=m[2].replace('.','-');r['export_time']=m[3];r['year']=int(m[2][:4]);counts[r['year']]+=1;r['doc_id']=f"D{r['year']}-{counts[r['year']]:04}";r['title']=next(p['text'].strip() for p in ps if p['text'].strip());r['url']=next((p['text'].strip() for p in ps[i+1:] if re.match(r'https?://',p['text'].strip())),None);r['content_paragraphs']=ps[:i];del r['paragraphs']
(P/'parsed_stage.json').write_text(json.dumps(rs,ensure_ascii=False),encoding='utf-8')
print('COUNT',len(rs),'BY YEAR',counts)
print('SOURCES',collections.Counter(r.get('source_label') for r in rs).most_common())
print('MONTHS',sorted(collections.Counter(r.get('export_date','')[:7] for r in rs).items()))
for year in sorted(counts):
 subset=[r for r in rs if r['year']==year];(P/f'titles_{year}.txt').write_text('\n'.join(f"{r['export_position']:04} {r['doc_id']} {r['export_date']} {r['source_label']} | {r['title']}" for r in subset))
