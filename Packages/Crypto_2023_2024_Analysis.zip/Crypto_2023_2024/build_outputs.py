from pathlib import Path
import json,html,re
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
P=Path(__file__).resolve().parent
s=json.loads((P/'summary.json').read_text());rs=json.loads((P/'audit_863.json').read_text());cs=json.loads((P/'cases.json').read_text())
d=Document();sec=d.sections[0];sec.page_width=Inches(8.27);sec.page_height=Inches(11.69);sec.left_margin=sec.right_margin=Inches(.8);sec.top_margin=sec.bottom_margin=Inches(.7)
for name,size in [('Normal',11),('Title',19),('Subtitle',11),('Heading 1',14),('Heading 2',12)]:
 st=d.styles[name];st.font.name='Times New Roman';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0);st.paragraph_format.space_after=Pt(7)
d.styles['Normal'].paragraph_format.line_spacing=1.08
for el in list(d.styles.element.iter(qn('w:pBdr'))):el.getparent().remove(el)
sections=[];current=None
def p(t,style=None):
 d.add_paragraph(t,style)
 if current is not None: current['paragraphs'].append(t)
def h(t):
 global current
 current={'title':t,'paragraphs':[]};sections.append(current);d.add_paragraph(t,'Heading 1')
def page(t):d.add_page_break();h(t)
def table(headers,rows,widths):
 t=d.add_table(rows=1,cols=len(headers));t.autofit=False
 for c,w in zip(t.columns,widths):c.width=Inches(w)
 for c,tx in zip(t.rows[0].cells,headers):c.text=tx
 for row in rows:
  for c,tx in zip(t.add_row().cells,row):c.text=str(tx)
 borders=OxmlElement('w:tblBorders')
 for k in ['top','left','bottom','right','insideH','insideV']:
  e=OxmlElement('w:'+k);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
 t._tbl.tblPr.append(borders)
 for i,row in enumerate(t.rows):
  pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
  if i==0:pr.append(OxmlElement('w:tblHeader'))
  for c,w in zip(row.cells,widths):
   c.width=Inches(w)
   if i==0:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E5EAF0');c._tc.get_or_add_tcPr().append(sh)
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(5);pp.paragraph_format.space_before=Pt(4)
    for r in pp.runs:r.font.size=Pt(10);r.bold=i==0
 d.add_paragraph('')
from report_content import TITLE,PAGES
p(TITLE,'Title');p('Опрацювання корпусу InfoStream для дослідження та наукової статті','Subtitle')
for i,(title,paragraphs) in enumerate(PAGES):
 if i:page(title)
 else:h(title)
 for tx in paragraphs:
  if tx=='TABLE_COUNTS':
   table(['Рік','Записів','Основні','Контекст','Дайджест','Відсів','Сімейств'],[[y,v['all'],v['decision_counts'].get('MAIN',0),v['decision_counts'].get('CONTEXT',0),v['decision_counts'].get('SUPPLEMENT',0),v['excluded'],v['retained_families']] for y,v in s['years'].items()],[.46,.65,.8,.8,.8,.65,.8])
  elif tx=='TABLE_TRAJECTORY':
   table(['Період','Профіль документальних свідчень'],[['2011–2014','Оплата, викрадення, майнінг, змішування і спеціалізація посередників'],['2015–2020','Сервісна модель вимагання, багатoактивні та фіатні маршрути, OTC і простежування'],['2021–2022','Мости як цілі й інструменти; контракти, вкладені обмінники та процесуальна протидія'],['2023–2024','Адаптація сервісів, стейблкоїни, фіатні посередники та розгалуження судових процедур']],[1,5.1])
  elif tx=='TABLE_FLOWS':
   table(['Напрям','Приклад і межа висновку'],[['Готівка → крипто','Криптомат потерпілого — on-ramp, не фіатний вихід отримувача'],['Крипто → крипто','Horizon, WazirX — зміна активу або сервісу, не доказ фіату'],['Крипто → фіат → готівка','Maui — юані та ATM за викладом обвинувачення'],['Крипто → готівка → закупівлі','Lu Huaying — санкційний опис посередництва'],['Крипто → активи','Jian Wen — розмежовано спроби купівлі й ширше вилучення']],[1.8,4.3])
  elif tx=='FILES_NOTE':
   p('Матеріали для подальшої роботи','Heading 2');p('Audit_2023_2024.html містить усі 863 записи, 42 картки та уривки. cases.json зберігає статуси, періоди й сімейства справ; mechanism_routes.json — вісім фрагментів маршрутів; query_registry.json — версії запитів; entity_mapping.json — правила розмежування сутностей. Ідентифікатори D позначають документи, C — картки. Для бібліографії доступні назва, джерело, дата та URL експорту, які потребують редакційного звірення.')
  else:p(tx)
d.save(P/'Report_2023_2024.docx')
(P/'article_fragment.txt').write_text('\n\n'.join(x for x in PAGES[-1][1] if x!='FILES_NOTE')+'\n',encoding='utf-8')
E=html.escape
out=['<!doctype html><html lang="uk"><meta charset="utf-8"><title>Аудит корпусу 2023–2024</title><style>body{font:16px/1.5 system-ui;margin:auto;max-width:1100px;padding:25px;color:#17212b}header{position:sticky;top:0;background:#fff;padding:10px 0;border-bottom:1px solid #bbb}article,section{border-bottom:1px solid #ccd;padding:15px 0}pre{white-space:pre-wrap;font:14px/1.5 system-ui}input{width:45%;padding:8px}select{padding:8px}blockquote{border-left:3px solid #ccd;margin:10px 0;padding-left:15px}a{color:#1557a0}.meta{color:#526070}details{margin:8px 0}</style><h1>Аудит корпусу 2023–2024</h1><p>863 записи, 772 залишено; 42 аналітичні картки. Рішення MAIN означає предметну релевантність, а не доведеність злочину. Фільтри діють на документи, пошук у браузері також знаходить картки.</p><header><input id="q" placeholder="Пошук тексту або ID"><select id="y"><option value="">Усі роки</option><option>2023</option><option>2024</option></select><select id="z"><option value="">Усі рішення</option>']
for x in sorted(set(r['decision'] for r in rs)):out.append('<option>'+x+'</option>')
out.append('</select><span id="count"></span></header><h2>Аналітичні картки</h2>')
for c in cs:
 out.append(f'<section id="{c["case_id"]}"><h3>{E(c["case_id"]+" "+c["title"])}</h3><p class="meta">{E(c["event_period"]+" | "+c["claim_status"])}</p><p>{E(c["finding"])}</p><p><b>Межі висновку</b> {E(c["caution"])}</p>')
 for e in c['evidence']:
  out.append(f'<blockquote><a href="#{e["doc_id"]}">{e["doc_id"]}</a> · {E(e["publication_date"])} · абзац {e["paragraph"]}, рядок {e["line"]}<br>{E(e["quote"])}</blockquote>')
 out.append('</section>')
out.append('<h2>Повний реєстр</h2>')
for r in rs:
 out.append(f'<article id="{r["doc_id"]}" data-year="{r["year"]}" data-decision="{r["decision"]}"><h3>{E(r["doc_id"]+" "+r["title"])}</h3><p class="meta">{E(r["source_label"])} · {r["export_date"]} · {r["decision"]} · {r["family_id"]} · {E(r["decision_origin"])}</p><p>{E(r["reason"])}</p>')
 if r['url'] and re.match(r'^https?://',r['url']):out.append(f'<p><a href="{E(r["url"],quote=True)}">URL експорту</a></p>')
 out.append('<details><summary>Виділений текст</summary><pre>'+E(r['body'])+'</pre></details><details><summary>Повний вихідний текст запису з координатами</summary><pre>'+E('\n'.join(str(x['paragraph'])+":"+str(x['line'])+" "+x['text'] for x in r['content_paragraphs']))+'</pre></details></article>')
out.append('''<script>const rows=[...document.querySelectorAll('article')];for(const r of rows)r._search=r.textContent.toLowerCase();function filter(){const q=document.querySelector('#q').value.toLowerCase(),y=document.querySelector('#y').value,z=document.querySelector('#z').value;let n=0;for(const r of rows){r.hidden=!!((y&&r.dataset.year!==y)||(z&&r.dataset.decision!==z)||(q&&!r._search.includes(q)));if(!r.hidden)n++}document.querySelector('#count').textContent=' '+n+' / '+rows.length}for(const id of ['q','y','z'])document.getElementById(id).addEventListener('input',filter);filter();function reveal(){const r=document.getElementById(location.hash.slice(1));if(r&&r.tagName==='ARTICLE'){r.hidden=false;const d=r.querySelector('details');d.open=true;r.scrollIntoView()}}window.addEventListener('hashchange',reveal);reveal();</script></html>''')
(P/'Audit_2023_2024.html').write_text(''.join(out),encoding='utf-8')
print('Report and HTML created')
