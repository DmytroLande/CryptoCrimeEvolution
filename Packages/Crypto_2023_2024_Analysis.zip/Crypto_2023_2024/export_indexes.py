from pathlib import Path
import json,csv
P=Path(__file__).resolve().parent
rs=json.loads((P/'audit_863.json').read_text());cs=json.loads((P/'cases.json').read_text());ref={}
for c in cs:
 for e in c['evidence']:ref.setdefault(e['doc_id'],set()).add(c['case_id'])
with (P/'bibliography.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['doc_id','publication_export_date','source_label','original_export_title','url','cited_in_cards'])
 for r in rs:
  if r['doc_id'] in ref:w.writerow([r['doc_id'],r['export_date'],r['source_label'],r['title'],r['url'],'; '.join(sorted(ref[r['doc_id']]))])
with (P/'document_index.csv').open('w',encoding='utf-8-sig',newline='') as f:
 cols=['doc_id','export_position','export_date','source_label','title','url','decision','reason','family_id','family_size','canonical_doc_id','source_type'];w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(rs)
print('Bibliographic sources',len(ref),'records',len(rs))
