from pathlib import Path
import json,collections,platform,importlib.metadata,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
s=json.loads((P/'summary.json').read_text());rs=json.loads((P/'audit_863.json').read_text());cs=json.loads((P/'cases.json').read_text());by={c['case_id']:c for c in cs}
def save(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
prev=json.loads((P/'prior_metadata.json').read_text())
q=prev['query_registry'];q['versions'].append({'period':'2023–2024','query_verbatim_spacing_normalized':s['query'],'source':'query table in 2024.docx','syntax_not_validated':['OTC]'],'changes':['cryptoasset returns; ethereum, monero and DeFi removed as literal first-block terms','USDT and DEX appear without the trailing bracket variants of preceding export','Preserve adaptive vocabulary, functions and selection effects; absence from query is not disappearance of entity']});save('query_registry.json',q)
e=prev['entity_mapping'];e['rules'] += [
 {'entity':'Tron / TRX / USDT on Tron','meaning':'Network, native asset and issued stablecoin are separate entities; network counts do not give all token volumes'},
 {'entity':'Blender / Sinbad / YoMix / Yonmix','meaning':'Separate service identities; Blender-Sinbad relationship attributed probabilistically; Yonmix spelling not silently merged with YoMix'},
 {'entity':'Railgun / Tornado Cash','meaning':'Distinct services, do not collapse into same named mixer'},
 {'entity':'Tornado US criminal / NL criminal / US OFAC civil','meaning':'Separate defendants, legal claims, courts and procedural time lines'},
 {'entity':'Larry Harmon / Gary Harmon','meaning':'Different persons and proceedings; Helix operator versus theft of seized assets'},
 {'entity':'Maui / Sino-Korean Friendship Bridge / ATM','meaning':'Malware; physical geographic bridge; fiat withdrawal ATM. Not all bridge/ATM hits are blockchain tools'},
 {'entity':'PM2BTC / Cryptex / Cryptonator','meaning':'Distinct services; coordinated enforcement does not prove one entity or assign collective sums to each'},
 {'entity':'FTX external theft / SBF / Alameda','meaning':'Separate event families and attribution; co-occurring coverage does not join money trails'},
 {'entity':'Whirlpool / Ricochet / Samourai','meaning':'Mixing feature, additional hops feature and wallet service; preserve custody/control distinctions'},
 {'entity':'Wang account / beneficiary','meaning':'Registered account holder not automatically controller or ultimate recipient'},
 {'entity':'cashout / bank transfer / crypto ATM','meaning':'Record direction and completion; on-ramp, crypto swap, fiat receipt and announced victim return are separate states'}];save('entity_mapping.json',e)
i=prev['cumulative_inventory'];i['all_records']+=s['all'];i['batches'].append({'period':'2023–2024','all':s['all']});save('cumulative_inventory.json',i)
links=[
 ('C21-02','C24-04','Helix','2020 charges → 2021 plea → 2024 sentence'),
 ('C21-03','C24-03','Bitcoin Fog','2021 charges → 2024 conviction and sentence; service operated 2011–2021'),
 ('C22-13','C23-11','Bitfinex_2016','2022 charges/seizure → 2023 plea'),
 ('C23-11','C24-05','Bitfinex_2016','2023 plea → 2024 sentence'),
 ('C22-06','C23-02','Horizon','2022 preliminary attribution → 2023 FBI attribution and movement'),
 ('C22-01','C23-03','Ronin','2022 theft → 2023 Norway seizure; no assumption recoveries disjoint'),
 ('C22-02','C23-04','Blender_Sinbad','2022 Blender sanction → 2023 attributed relationship, not established identity'),
 ('C23-04','C23-18','Sinbad','early relationship hypothesis → later sanction'),
 ('C23-18','C24-01','Lazarus_laundering','sources describe change of mixer; no inferred transaction linking all cases'),
 ('C22-03','C23-12','Tornado_US_criminal','2022 sanction and 2023 criminal charges are different actions'),
 ('C22-05','C24-06','Tornado_NL_criminal','2022 arrest → 2024 sentence'),
 ('C22-04','C24-07','Tornado_OFAC_civil','2022 six-user challenge → 2024 appellate decision'),
 ('C22-12','C24-21','Garantex','2022 sanctions → 2024 investigation and disputed attributions'),
 ('C23-06','C24-11','Sim_network','2023 charges and 2024 sanctions describe related network, not a single combined flow'),
 ('C22-20','C23-09','MiCA','2022 provisional agreement → 2023 formal adoption'),
 ('C23-10',None,'MtGox_BTCe','Retrospective 2023 allegation about theft from 2011 and bank payments 2012–2013')]
save('continuity_links.json',{'meaning':'Analyst-curated continuity, not transaction edges; prior IDs refer to earlier packages','links':[dict(from_case=a,to_case=b,family=f,relationship=r) for a,b,f,r in links]})
save('case_family_index.json',{'families':[{'family':f,'cards':[c['case_id'] for c in cs if c['case_family']==f]} for f in sorted(set(c['case_family'] for c in cs))]})
save('topic_screening_counts.json',{'meaning':'Lexical document indicators, not cases, mechanisms or crime counts. Multiple tags overlap.','years':{str(y):dict(collections.Counter(t for r in rs if r['year']==y and not r['decision'].startswith('EXCLUDE') for t in r['tags'])) for y in [2023,2024]}})
save('source_anomalies.json',{'input_records':863,'declared_export_records':863,'source_hash':s['sha256'],'items':[
 {'docs':['D2023-0356'],'issue':'Horizon incident dated 2020 within ChipMixer publication','treatment':'Retain original; use June 2022 from explicit Horizon case sources'},
 {'docs':['D2024-0241'],'issue':'Headline 2bn; body 1.2 and 2.2bn depending on selection parameters','treatment':'Preserve denominators, do not add or choose headline as uniform estimate'},
 {'docs':['D2023-0114','D2023-0120'],'issue':'Elliptic release gives cumulative to July 2023, illicit OR high-risk; not 2023 annual crime amount','treatment':'Retain scope and vintage; circulated release not independent publications'},
 {'docs':['D2024-0077','D2024-0339'],'issue':'Yonmix spelling in one text versus YoMix','treatment':'Do not silently merge service identities'},
 {'docs':['D2024-0115'],'issue':'Relative last month in September report; external chronology and absolute event date not provided by this phrase','treatment':'Use July event context separately, do not derive month from relative phrase; main theft cohort not independently verified'},
 {'docs':['D2023-0058','D2024-0317'],'issue':'return phrasing/headline versus clear seizure or announced future return','treatment':'Do not assert completed victim payout'},
 {'docs':['D2024-0101','D2024-0103'],'issue':'News pages repeat Cryptex block alongside unrelated stories','treatment':'Supplement, same case family; full text preserved'},
 {'docs':['D2024-0275','D2023-0356'],'issue':'Breadcrumb title in export despite substantive official release','treatment':'Original title preserved; case title separately supplied by analyst'},
 {'docs':['D2023-0187'],'issue':'May attempt cashout statement','treatment':'Potential future action, not executed fiat exit'}]})
routes=[]
def route(rid,cid,kind,labels,statuses):
 c=by[cid];nodes=[dict(node_id=rid+'_'+str(i),label=t) for i,t in enumerate(labels)]
 edges=[dict(source=nodes[i]['node_id'],target=nodes[i+1]['node_id'],relation='documented_semantic_stage',status=statuses[i]) for i in range(len(labels)-1)]
 routes.append(dict(route_id=rid,case_id=cid,kind=kind,nodes=nodes,edges=edges,evidence=c['evidence'],caution=c['caution']))
route('R01','C24-10','alleged_fiat_exit',['Викуп у криптовалюті','Гонконзькі посередники','Китайські юані','Зняття готівки у банкоматі'],['alleged','alleged','alleged'])
route('R02','C24-11','sanctions_description',['Криптовалютні доходи мережі Sim','Lu Huaying — cash-out і money mules','Фіатна готівка та оплата закупівель'],['sanctions_assessment','sanctions_assessment'])
route('R03','C23-10','retrospective_alleged_bank_exit',['Викрадений BTC Mt Gox','Біржові рахунки','Брокер і фіктивний рекламний контракт','Закордонні банківські рахунки 2012–2013'],['alleged','alleged','alleged'])
route('R04','C23-02','partial_crypto_swap',['Викрадені активи Horizon','ETH через Railgun','Три біржі','Частковий обмін на BTC'],['reported_FBI_attribution','reported','reported_no_fiat_proof'])
route('R05','C24-16','victim_onramp',['Готівка потерпілої','Криптомат','Криптогаманець у біржовій інфраструктурі','Імовірний вкладений P2P-сервіс'],['reported','reported','analytical_inference'])
route('R06','C24-12','reported_crypto_obfuscation',['Викрадені активи WazirX','Обмін значної частини на ETH','Переміщення через Tornado Cash'],['analyst_report','analyst_report_no_fiat_proof'])
route('R07','C24-02','heuristic_investigation',['Контрольний або отриманий BTC','Monero','BTC і дані біржі та електронної пошти'],['investigative_account','heuristic_inference_disputed'])
route('R08','C24-15','seizure_and_announced_return',['Гроші потерпілих','Криптовалюта на гаманцях шахраїв','Вилучення близько 1,4 млн USDT','Оголошене майбутнє повернення потерпілим'],['reported','reported_seizure','announced_future'])
save('mechanism_routes.json',{'meaning':'Eight partial source-backed semantic sequences; not onchain reconstruction. Nodes are scoped per route, no completion across unrelated cases. Stage status is attributed to the source.','routes':routes})
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
root=ET.Element('{'+ns+'}graphml');ET.SubElement(root,'{'+ns+'}key',id='label',**{'for':'node','attr.name':'label','attr.type':'string'});ET.SubElement(root,'{'+ns+'}key',id='status',**{'for':'edge','attr.name':'status','attr.type':'string'});g=ET.SubElement(root,'{'+ns+'}graph',edgedefault='directed')
for r in routes:
 for n in r['nodes']:
  el=ET.SubElement(g,'{'+ns+'}node',id=n['node_id']);ET.SubElement(el,'{'+ns+'}data',key='label').text=n['label']
 for i,e in enumerate(r['edges']):
  el=ET.SubElement(g,'{'+ns+'}edge',id=r['route_id']+'e'+str(i),source=e['source'],target=e['target']);ET.SubElement(el,'{'+ns+'}data',key='status').text=e['status']
ET.ElementTree(root).write(P/'Mechanism_routes.graphml',encoding='utf-8',xml_declaration=True)
save('runtime_versions.json',{'python':platform.python_version(),'packages':{x:importlib.metadata.version(x) for x in ['python-docx','numpy','scikit-learn']}})
print('Supplementary registers and eight route fragments created')
